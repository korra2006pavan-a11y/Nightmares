"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { DEMO_ADMIN, DEMO_MEMBER, PLAN, SITE } from "@/lib/config";
import { apiFetch } from "@/lib/image";
import type { Me } from "@/lib/types";

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await apiFetch<{ user: Me; redirect: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ identifier, password }),
      });
      router.push(data.redirect);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-6xl flex-col px-5 py-8">
      <Link href="/" className="flex items-center gap-2.5 self-start">
        <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-rose to-rose-deep">
          ❤
        </span>
        <span className="display text-xl">{SITE.name}</span>
      </Link>

      <div className="grid flex-1 items-center gap-12 py-10 lg:grid-cols-2">
        <div className="hidden lg:block">
          <h1 className="display text-5xl leading-tight">
            Welcome back to
            <br />
            <span className="bg-gradient-to-r from-rose to-gold bg-clip-text text-transparent">
              people, not profiles.
            </span>
          </h1>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-cream/60">
            Sign in with the login ID you created. Verified members get nearest-first discovery,
            private contact sharing and moderated chat for ₹{PLAN.amount} a month.
          </p>
          <div className="mt-8 space-y-3">
            {[
              ["✓", "Only OTP-verified, selfie-checked accounts appear in discovery"],
              ["✓", "Your number stays hidden until you allow it"],
              ["✓", "Fake profile? Report once — moderation takes over"],
            ].map(([icon, text]) => (
              <p key={text} className="flex gap-3 text-[13px] text-cream/65">
                <span className="text-mint">{icon}</span> {text}
              </p>
            ))}
          </div>
        </div>

        <div className="card mx-auto w-full max-w-md p-7">
          <h2 className="display text-2xl">Sign in</h2>
          <p className="mt-1 text-xs text-cream/45">Login ID, email or mobile number</p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="label" htmlFor="identifier">Login ID</label>
              <input
                id="identifier"
                className="input"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="ananya / demo@milap.in"
                autoComplete="username"
                required
              />
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                className="input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
            </div>
            {error && (
              <p className="rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-xs text-rose">
                {error}
              </p>
            )}
            <button className="btn-primary w-full" disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
            </button>
          </form>

          <div className="mt-5 rounded-2xl border border-white/10 bg-black/25 p-3">
            <p className="text-[10px] uppercase tracking-widest text-cream/35">Demo accounts</p>
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => {
                  setIdentifier(DEMO_MEMBER.loginId);
                  setPassword(DEMO_MEMBER.password);
                }}
                className="rounded-xl border border-mint/25 bg-mint/10 px-3 py-2 text-left text-[11px] text-mint hover:bg-mint/20"
              >
                <span className="block font-semibold">Verified member</span>
                {DEMO_MEMBER.loginId} / {DEMO_MEMBER.password}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIdentifier(DEMO_ADMIN.loginId);
                  setPassword(DEMO_ADMIN.password);
                }}
                className="rounded-xl border border-gold/25 bg-gold/10 px-3 py-2 text-left text-[11px] text-gold hover:bg-gold/20"
              >
                <span className="block font-semibold">Admin console</span>
                {DEMO_ADMIN.loginId} / {DEMO_ADMIN.password}
              </button>
            </div>
          </div>

          <p className="mt-5 text-center text-xs text-cream/45">
            New here?{" "}
            <Link href="/signup" className="font-semibold text-rose hover:underline">
              Create a verified profile
            </Link>
          </p>
          <p className="mt-2 text-center text-[11px] text-cream/30">
            <Link href="/admin/login" className="hover:text-cream/60">Admin login</Link>
          </p>
        </div>
      </div>
    </main>
  );
}
