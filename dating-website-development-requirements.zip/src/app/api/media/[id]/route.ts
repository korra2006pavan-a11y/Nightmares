import { eq } from "drizzle-orm";
import { db } from "@/db";
import { media } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Gated media delivery.
 * - payment screenshots: owner + admin only
 * - verification selfies: owner + admin only
 * - profile photos / chat images: owner, admin, or an active member
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const mediaId = Number(id);
  if (!Number.isInteger(mediaId)) return new Response("Not found", { status: 404 });

  const viewer = await getSessionUser();
  if (!viewer) return new Response("Sign in required", { status: 401 });

  const rows = await db.select().from(media).where(eq(media.id, mediaId)).limit(1);
  const asset = rows[0];
  if (!asset) return new Response("Not found", { status: 404 });

  const isOwner = asset.ownerId === viewer.id;
  const isAdmin = viewer.role === "admin";
  const member = hasActiveMembership(viewer);
  const allowed =
    isOwner || isAdmin || ((asset.kind === "photo" || asset.kind === "chat") && member);

  if (!allowed) return new Response("Membership required", { status: 403 });

  const buffer = Buffer.from(asset.data, "base64");
  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": asset.mime,
      "Content-Length": String(buffer.length),
      "Cache-Control": isOwner || isAdmin ? "private, max-age=60" : "private, max-age=3600",
    },
  });
}
