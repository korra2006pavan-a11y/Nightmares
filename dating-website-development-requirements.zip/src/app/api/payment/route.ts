import { and, desc, eq, gt, or } from "drizzle-orm";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { hasActiveMembership, membershipDaysLeft } from "@/lib/auth";
import {
  fail,
  ok,
  parseDataUrl,
  readJson,
  requireUser,
  saveMedia,
} from "@/lib/api";
import { ADMIN_UPI_ID, ADMIN_UPI_NAME, PLAN } from "@/lib/config";
import { refreshTrust, runUtrCheck } from "@/lib/verification";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await requireUser();
  if (!session.user) return session.error;
  const user = session.user;

  const history = await db
    .select()
    .from(payments)
    .where(eq(payments.userId, user.id))
    .orderBy(desc(payments.createdAt))
    .limit(8);

  const note = `MILAP-${user.loginId.toUpperCase()}`;
  const upiLink = `upi://pay?pa=${encodeURIComponent(ADMIN_UPI_ID)}&pn=${encodeURIComponent(
    ADMIN_UPI_NAME,
  )}&am=${PLAN.amount}&cu=INR&tn=${encodeURIComponent(note)}`;

  return ok({
    plan: { ...PLAN, upiId: ADMIN_UPI_ID, upiName: ADMIN_UPI_NAME, note },
    upiLink,
    requirements: {
      emailVerified: Boolean(user.emailVerifiedAt),
      phoneVerified: Boolean(user.phoneVerifiedAt),
      hasPhoto: Boolean(user.photoMediaId || user.photoUrl),
      hasSelfie: Boolean(user.selfieMediaId),
      isMember: hasActiveMembership(user),
    },
    membership: {
      status: user.membershipStatus,
      expiresAt: user.membershipExpiresAt
        ? new Date(user.membershipExpiresAt).toISOString()
        : null,
      daysLeft: membershipDaysLeft(user),
    },
    payments: history.map((p) => ({
      id: p.id,
      utr: p.utr,
      amount: p.amount,
      status: p.status,
      verdict: p.verdict,
      checkerNote: p.checkerNote,
      screenshotUrl: p.screenshotMediaId ? `/api/media/${p.screenshotMediaId}` : null,
      createdAt: new Date(p.createdAt).toISOString(),
    })),
  });
}

export async function POST(request: Request) {
  const session = await requireUser();
  if (!session.user) return session.error;
  const user = session.user;

  if (hasActiveMembership(user)) {
    return fail("Your membership is already active.", 409);
  }
  if (!user.emailVerifiedAt || !user.phoneVerifiedAt) {
    return fail("Verify both email and mobile OTP before paying.", 403);
  }

  const body = await readJson<{ utr?: string; screenshot?: string }>(request);
  const utr = (body?.utr ?? "").replace(/\s+/g, "");
  if (!utr) return fail("Enter the 12-digit UTR from your UPI app.");

  const image = parseDataUrl(body?.screenshot);
  if (!image) return fail("Upload a clear payment screenshot (JPG/PNG/WebP under 3.5 MB).");

  const recent = await db
    .select({ id: payments.id })
    .from(payments)
    .where(
      and(
        eq(payments.userId, user.id),
        gt(payments.createdAt, new Date(Date.now() - 24 * 60 * 60 * 1000)),
      ),
    );

  const check = await runUtrCheck({
    utr,
    userId: user.id,
    screenshotMediaId: 1,
    recentSubmissions: recent.length,
    amount: PLAN.amount,
  });

  if (check.verdict === "rejected") {
    return fail(check.message, 400, { verdict: check.verdict, code: check.code });
  }

  const screenshotMediaId = await saveMedia(user.id, "payment", image);

  if (check.verdict === "needs_review") {
    const [row] = await db
      .insert(payments)
      .values({
        userId: user.id,
        amount: PLAN.amount,
        upiId: ADMIN_UPI_ID,
        utr,
        screenshotMediaId,
        status: "needs_review",
        verdict: "needs_review",
        checkerNote: check.message,
      })
      .onConflictDoNothing()
      .returning();
    if (!row) {
      return fail("This UTR has already been submitted. Try a different reference.", 409);
    }
    return ok({
      verdict: "needs_review",
      message: `${check.message} Your UTR is queued for manual review — usually within a few hours.`,
      paymentId: row.id,
    });
  }

  const base =
    user.membershipExpiresAt && new Date(user.membershipExpiresAt).getTime() > Date.now()
      ? new Date(user.membershipExpiresAt)
      : new Date();
  const expiresAt = new Date(base.getTime() + PLAN.days * 24 * 60 * 60 * 1000);

  const [row] = await db
    .insert(payments)
    .values({
      userId: user.id,
      amount: PLAN.amount,
      upiId: ADMIN_UPI_ID,
      utr,
      screenshotMediaId,
      status: "verified",
      verdict: "verified",
      checkerNote: check.message,
    })
    .onConflictDoNothing()
    .returning();

  if (!row) return fail("This UTR has already been used. Reference blocked.", 409);

  await db
    .update(users)
    .set({
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: expiresAt,
      trustScore: Math.min(100, user.trustScore + 10),
      status: user.status === "under_review" ? "active" : user.status,
      statusReason: user.status === "under_review" ? null : user.statusReason,
    })
    .where(eq(users.id, user.id));
  await refreshTrust(user.id);

  return ok({
    verdict: "verified",
    message: "UTR verified. Membership active — photos, contacts and chat unlocked.",
    membershipExpiresAt: expiresAt.toISOString(),
    paymentId: row.id,
  });
}

/** Helper used by the UI to explain what the UTR checker enforces. */
export const UTR_RULES = [
  "12-digit numeric UPI reference (UTR / RRN)",
  "Reference must be unused across the whole platform",
  "Payment screenshot must be attached",
  `Amount must match ₹${PLAN.amount}`,
  "Repeating-digit or high-velocity submissions go to manual review",
];
