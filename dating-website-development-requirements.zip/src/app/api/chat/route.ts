import { and, desc, eq, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { mutualMatchIds } from "@/lib/verification";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return fail("Sign in required.", 401);

  const matchIds = await mutualMatchIds(viewer.id);
  if (matchIds.length === 0) {
    return ok({ isMember: hasActiveMembership(viewer), threads: [], totalUnread: 0 });
  }

  const partners = await db
    .select()
    .from(users)
    .where(and(inArray(users.id, matchIds), eq(users.status, "active")));

  const allMessages = await db
    .select()
    .from(messages)
    .where(
      or(
        and(eq(messages.senderId, viewer.id), inArray(messages.receiverId, matchIds)),
        and(eq(messages.receiverId, viewer.id), inArray(messages.senderId, matchIds)),
      ),
    )
    .orderBy(desc(messages.createdAt));

  const unreadRows = await db
    .select({ senderId: messages.senderId, count: sql<number>`count(*)::int` })
    .from(messages)
    .where(and(eq(messages.receiverId, viewer.id), isNull(messages.readAt)))
    .groupBy(messages.senderId);
  const unreadMap = new Map(unreadRows.map((r) => [r.senderId, Number(r.count)]));

  const threads = partners
    .map((partner) => {
      const thread = allMessages.filter(
        (m) =>
          (m.senderId === viewer.id && m.receiverId === partner.id) ||
          (m.receiverId === viewer.id && m.senderId === partner.id),
      );
      const last = thread[0];
      return {
        userId: partner.id,
        fullName: partner.fullName,
        photoUrl:
          partner.showPhoto || hasActiveMembership(viewer)
            ? (partner.photoMediaId ? `/api/media/${partner.photoMediaId}` : partner.photoUrl)
            : null,
        city: partner.city,
        area: partner.area,
        identityVerified: partner.identityVerified,
        unread: unreadMap.get(partner.id) ?? 0,
        lastMessage: last
          ? {
              body: last.body,
              hasImage: Boolean(last.mediaId),
              fromMe: last.senderId === viewer.id,
              at: new Date(last.createdAt).toISOString(),
            }
          : null,
      };
    })
    .sort((a, b) => {
      const at = a.lastMessage ? new Date(a.lastMessage.at).getTime() : 0;
      const bt = b.lastMessage ? new Date(b.lastMessage.at).getTime() : 0;
      return bt - at;
    });

  return ok({
    isMember: hasActiveMembership(viewer),
    totalUnread: threads.reduce((sum, t) => sum + t.unread, 0),
    threads,
  });
}
