import { and, asc, eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { media, messages, users } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import {
  fail,
  ok,
  parseDataUrl,
  readJson,
  requireMember,
  saveMedia,
} from "@/lib/api";
import { mutualMatchIds, otherMemberExists } from "@/lib/verification";

export const dynamic = "force-dynamic";

async function loadThread(viewerId: number, partnerId: number) {
  const rows = await db
    .select({ message: messages, mime: media.mime })
    .from(messages)
    .leftJoin(media, eq(media.id, messages.mediaId))
    .where(
      or(
        and(eq(messages.senderId, viewerId), eq(messages.receiverId, partnerId)),
        and(eq(messages.senderId, partnerId), eq(messages.receiverId, viewerId)),
      ),
    )
    .orderBy(asc(messages.createdAt));
  return rows.map((row) => ({
    id: row.message.id,
    body: row.message.body,
    mediaId: row.message.mediaId,
    fromMe: row.message.senderId === viewerId,
    at: new Date(row.message.createdAt).toISOString(),
    read: Boolean(row.message.readAt),
  }));
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ userId: string }> },
) {
  const viewer = await getSessionUser();
  if (!viewer) return fail("Sign in required.", 401);
  const partnerId = Number((await params).userId);
  const partner = await otherMemberExists(viewer.id, partnerId);
  if (!partner) return fail("Profile not found.", 404);

  const matches = await mutualMatchIds(viewer.id);
  const isMatch = matches.includes(partnerId);

  await db
    .update(messages)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(messages.senderId, partnerId),
        eq(messages.receiverId, viewer.id),
        isNull(messages.readAt),
      ),
    );

  const thread = await loadThread(viewer.id, partnerId);
  const canSeeImages = viewer.id === partnerId ? true : partner.allowChatPhotos;

  return ok({
    partner: {
      id: partner.id,
      fullName: partner.fullName,
      loginId: partner.loginId,
      city: partner.city,
      area: partner.area,
      photoUrl: (partner.photoMediaId
        ? `/api/media/${partner.photoMediaId}`
        : partner.photoUrl),
      identityVerified: partner.identityVerified,
      showContact: partner.showContact,
      phone: isMatch && partner.showContact ? partner.phone : null,
      allowChatPhotos: partner.allowChatPhotos,
    },
    isMember: hasActiveMembership(viewer),
    isMatch,
    viewerAllowChatPhotos: viewer.allowChatPhotos,
    messages: thread.map((m) => ({
      ...m,
      imageUrl: m.mediaId && (m.fromMe || canSeeImages) ? `/api/media/${m.mediaId}` : null,
      imageBlocked: Boolean(m.mediaId) && !m.fromMe && !canSeeImages,
    })),
  });
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ userId: string }> },
) {
  const session = await requireMember();
  if (!session.user) return session.error;
  const viewer = session.user;
  const partnerId = Number((await params).userId);
  if (partnerId === viewer.id) return fail("You cannot message yourself.");

  const partner = await otherMemberExists(viewer.id, partnerId);
  if (!partner) return fail("Profile not found.", 404);

  const matches = await mutualMatchIds(viewer.id);
  if (!matches.includes(partnerId))
    return fail("Chat unlocks when you both like each other.", 403);

  const body = await readJson<{ body?: string; image?: string }>(request);
  const text = (body?.body ?? "").trim().slice(0, 2000);
  const image = body?.image ? parseDataUrl(body.image) : null;
  if (!text && !body?.image) return fail("Write a message or attach a photo.");
  if (body?.image && !image) return fail("Photo must be a JPG/PNG/WebP under 3.5 MB.");
  if (image && !partner.allowChatPhotos)
    return fail(`${partner.fullName.split(" ")[0]} has turned off photo sharing in chat.`, 403);
  if (image && !viewer.allowChatPhotos)
    return fail("Turn on 'Allow photos in chat' in Settings to send images.", 403);

  const mediaId = image ? await saveMedia(viewer.id, "chat", image) : null;
  const [created] = await db
    .insert(messages)
    .values({ senderId: viewer.id, receiverId: partnerId, body: text, mediaId })
    .returning();

  return ok({
    message: {
      id: created.id,
      body: created.body,
      mediaId: created.mediaId,
      fromMe: true,
      at: new Date(created.createdAt).toISOString(),
      read: false,
      imageUrl: mediaId ? `/api/media/${mediaId}` : null,
      imageBlocked: false,
    },
  });
}
