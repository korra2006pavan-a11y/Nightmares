import { eq } from "drizzle-orm";
import { db } from "@/db";
import { reports, users } from "@/db/schema";
import { fail, ok, readJson, requireAdmin } from "@/lib/api";
import { refreshTrust } from "@/lib/verification";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireAdmin();
  if (!session.user) return session.error;
  const reportId = Number((await params).id);
  const body = await readJson<{ action?: string }>(request);
  const action = body?.action;
  if (!["dismiss", "uphold", "ban"].includes(action ?? "")) return fail("Unknown action.");

  const [report] = await db.select().from(reports).where(eq(reports.id, reportId)).limit(1);
  if (!report) return fail("Report not found.", 404);

  if (action === "dismiss") {
    await db
      .update(reports)
      .set({ status: "dismissed", resolvedAt: new Date() })
      .where(eq(reports.id, reportId));
  } else {
    await db
      .update(reports)
      .set({ status: "resolved", resolvedAt: new Date() })
      .where(eq(reports.id, reportId));
    if (action === "ban") {
      await db
        .update(users)
        .set({
          status: "banned",
          membershipStatus: "expired",
          statusReason: `Banned after report: ${report.reason}`,
        })
        .where(eq(users.id, report.reportedUserId));
    } else {
      await db
        .update(users)
        .set({
          status: "under_review",
          statusReason: `Upheld member report: ${report.reason}`,
        })
        .where(eq(users.id, report.reportedUserId));
    }
    await refreshTrust(report.reportedUserId);
  }

  return ok({ ok: true, message: `Report ${action}ed.` });
}
