import { eq } from "drizzle-orm";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { fail, ok, readJson, requireAdmin } from "@/lib/api";
import { PLAN } from "@/lib/config";
import { refreshTrust } from "@/lib/verification";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireAdmin();
  if (!session.user) return session.error;

  const paymentId = Number((await params).id);
  const body = await readJson<{ action?: string; note?: string }>(request);
  const action = body?.action;
  if (!["approve", "reject"].includes(action ?? "")) return fail("Unknown action.");

  const [payment] = await db
    .select()
    .from(payments)
    .where(eq(payments.id, paymentId))
    .limit(1);
  if (!payment) return fail("Payment not found.", 404);

  const [member] = await db.select().from(users).where(eq(users.id, payment.userId)).limit(1);
  if (!member) return fail("Member not found.", 404);

  const note = (body?.note ?? "").slice(0, 500);

  if (action === "approve") {
    const base =
      member.membershipExpiresAt && new Date(member.membershipExpiresAt).getTime() > Date.now()
        ? new Date(member.membershipExpiresAt)
        : new Date();
    const expiresAt = new Date(base.getTime() + PLAN.days * 24 * 60 * 60 * 1000);
    await db
      .update(payments)
      .set({
        status: "verified",
        verdict: "verified",
        reviewedBy: session.user.id,
        reviewedAt: new Date(),
        checkerNote:
          note || "Manually verified by admin against the bank credit statement.",
      })
      .where(eq(payments.id, paymentId));
    await db
      .update(users)
      .set({
        membershipStatus: "active",
        membershipPlan: PLAN.id,
        membershipExpiresAt: expiresAt,
        status: "active",
        statusReason: null,
      })
      .where(eq(users.id, member.id));
    await refreshTrust(member.id);
    return ok({ ok: true, message: `${member.fullName} upgraded for 30 days.`, expiresAt });
  }

  await db
    .update(payments)
    .set({
      status: "rejected",
      verdict: "rejected",
      reviewedBy: session.user.id,
      reviewedAt: new Date(),
      checkerNote: note || "Rejected — payment could not be matched with a bank credit.",
    })
    .where(eq(payments.id, paymentId));
  if (member.membershipStatus === "pending") {
    await db
      .update(users)
      .set({ membershipStatus: "none" })
      .where(eq(users.id, member.id));
  }
  return ok({ ok: true, message: `Payment rejected for ${member.fullName}.` });
}
