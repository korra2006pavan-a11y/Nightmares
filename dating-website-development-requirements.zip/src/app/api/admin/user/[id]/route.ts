import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  likes,
  media,
  messages,
  otps,
  payments,
  reports,
  sessions,
  users,
} from "@/db/schema";
import { fail, ok, readJson, requireAdmin } from "@/lib/api";
import { PLAN } from "@/lib/config";
import { refreshTrust } from "@/lib/verification";

const ACTIONS = [
  "verify_identity",
  "reject_identity",
  "grant_membership",
  "revoke_membership",
  "flag",
  "unflag",
  "ban",
  "restore",
] as const;

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireAdmin();
  if (!session.user) return session.error;

  const userId = Number((await params).id);
  const body = await readJson<{ action?: string; note?: string }>(request);
  const action = body?.action;
  if (!ACTIONS.includes((action ?? "") as (typeof ACTIONS)[number]))
    return fail("Unknown action.");

  const [member] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!member) return fail("Member not found.", 404);
  if (member.role === "admin") return fail("Admin accounts cannot be modified here.", 403);

  const note = (body?.note ?? "").slice(0, 400);

  switch (action) {
    case "verify_identity":
      await db
        .update(users)
        .set({
          identityVerified: true,
          status: "active",
          statusReason: null,
        })
        .where(eq(users.id, userId));
      break;
    case "reject_identity":
      await db
        .update(users)
        .set({
          identityVerified: false,
          status: "under_review",
          statusReason: note || "Selfie did not match the profile photo.",
        })
        .where(eq(users.id, userId));
      break;
    case "grant_membership": {
      const base =
        member.membershipExpiresAt && new Date(member.membershipExpiresAt).getTime() > Date.now()
          ? new Date(member.membershipExpiresAt)
          : new Date();
      await db
        .update(users)
        .set({
          membershipStatus: "active",
          membershipPlan: "admin_grant",
          membershipExpiresAt: new Date(base.getTime() + PLAN.days * 86_400_000),
        })
        .where(eq(users.id, userId));
      break;
    }
    case "revoke_membership":
      await db
        .update(users)
        .set({ membershipStatus: "expired", membershipExpiresAt: new Date() })
        .where(eq(users.id, userId));
      break;
    case "flag":
      await db
        .update(users)
        .set({
          status: "under_review",
          statusReason: note || "Flagged by Trust & Safety for review.",
        })
        .where(eq(users.id, userId));
      break;
    case "unflag":
    case "restore":
      await db
        .update(users)
        .set({ status: "active", statusReason: null })
        .where(eq(users.id, userId));
      break;
    case "ban":
      await db
        .update(users)
        .set({
          status: "banned",
          statusReason: note || "Removed for fake profile / policy violation.",
          membershipStatus: "expired",
        })
        .where(eq(users.id, userId));
      break;
  }

  await refreshTrust(userId);
  return ok({ ok: true, action, message: `Applied ${String(action).replace(/_/g, " ")}.` });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireAdmin();
  if (!session.user) return session.error;
  const userId = Number((await params).id);
  if (!Number.isInteger(userId)) return fail("Invalid member.");

  const [member] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!member) return fail("Member not found.", 404);
  if (member.role === "admin") return fail("Admin accounts cannot be deleted.", 403);

  await db.delete(messages).where(eq(messages.senderId, userId));
  await db.delete(messages).where(eq(messages.receiverId, userId));
  await db.delete(likes).where(eq(likes.fromUserId, userId));
  await db.delete(likes).where(eq(likes.toUserId, userId));
  await db.delete(reports).where(eq(reports.reporterId, userId));
  await db.delete(reports).where(eq(reports.reportedUserId, userId));
  await db.delete(payments).where(eq(payments.userId, userId));
  await db.delete(media).where(eq(media.ownerId, userId));
  await db.delete(otps).where(eq(otps.userId, userId));
  await db.delete(sessions).where(eq(sessions.userId, userId));
  await db.delete(users).where(eq(users.id, userId));

  return ok({ ok: true, message: `${member.fullName}'s account was permanently removed.` });
}
