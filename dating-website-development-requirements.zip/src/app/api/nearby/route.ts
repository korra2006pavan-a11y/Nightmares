import { and, eq, inArray, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { likes, users } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import { ok } from "@/lib/api";
import { CITIES, haversineKm } from "@/lib/geo";
import { toPublicProfile, type PublicProfile } from "@/lib/verification";

export const dynamic = "force-dynamic";

export type NearbyResponse = {
  signedIn: boolean;
  isMember: boolean;
  viewerName: string | null;
  origin: { lat: number; lng: number; label: string; fallback: boolean } | null;
  radiusKm: number;
  count: number;
  people: (PublicProfile & {
    isMatch: boolean;
    likedYou: boolean;
    youLiked: boolean;
    openReports?: number;
  })[];
};

export async function GET(request: Request) {
  const viewer = await getSessionUser();
  const url = new URL(request.url);
  const radiusKm = Math.min(500, Math.max(1, Number(url.searchParams.get("radius")) || 60));
  const gender = url.searchParams.get("gender") || "any";
  const minAge = Number(url.searchParams.get("minAge")) || 18;
  const maxAge = Number(url.searchParams.get("maxAge")) || 70;
  const verifiedOnly = url.searchParams.get("verified") === "1";
  const q = (url.searchParams.get("q") || "").trim().toLowerCase();

  const viewerCity = viewer?.city || "Hyderabad";
  const preset =
    CITIES.find((c) => c.name.toLowerCase() === viewerCity.toLowerCase()) ?? CITIES[0];
  const originLat = viewer?.lat ?? preset.lat;
  const originLng = viewer?.lng ?? preset.lng;
  const fallback = viewer?.lat == null || viewer?.lng == null;
  const isMember = viewer ? hasActiveMembership(viewer) : false;

  const rows = await db
    .select()
    .from(users)
    .where(
      and(
        eq(users.role, "member"),
        eq(users.status, "active"),
        viewer ? ne(users.id, viewer.id) : undefined,
        gender === "any" ? undefined : eq(users.gender, gender),
      ),
    );

  const ids = rows.map((r) => r.id);
  const likeRows =
    viewer && ids.length > 0
      ? await db
          .select()
          .from(likes)
          .where(
            and(
              eq(likes.action, "like"),
              or(
                and(eq(likes.fromUserId, viewer.id), inArray(likes.toUserId, ids)),
                and(eq(likes.toUserId, viewer.id), inArray(likes.fromUserId, ids)),
              ),
            ),
          )
      : [];

  const mine = new Set(
    likeRows.filter((l) => l.fromUserId === viewer?.id).map((l) => l.toUserId),
  );
  const theirs = new Set(
    likeRows.filter((l) => l.toUserId === viewer?.id).map((l) => l.fromUserId),
  );

  const people = rows
    .map((candidate) => {
      const distanceKm = haversineKm(originLat, originLng, candidate.lat ?? originLat, candidate.lng ?? originLng);
      const age = new Date().getFullYear() - candidate.birthYear;
      const profile = toPublicProfile(candidate, {
        viewer,
        distanceKm,
        contactUnlocked: false,
      });
      return {
        ...profile,
        age,
        isMatch: mine.has(candidate.id) && theirs.has(candidate.id),
        likedYou: theirs.has(candidate.id),
        youLiked: mine.has(candidate.id),
      };
    })
    .filter((p) => p.distanceKm === null || p.distanceKm <= radiusKm)
    .filter((p) => p.age >= minAge && p.age <= maxAge)
    .filter((p) => (verifiedOnly ? p.identityVerified : true))
    .filter((p) =>
      q
        ? `${p.fullName} ${p.city} ${p.area} ${p.bio} ${p.lookingFor}`.toLowerCase().includes(q)
        : true,
    )
    .sort((a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999));

  return ok<NearbyResponse>({
    signedIn: Boolean(viewer),
    isMember,
    viewerName: viewer?.fullName ?? null,
    origin: {
      lat: originLat,
      lng: originLng,
      label: viewer?.area ? `${viewer.area}, ${viewerCity}` : viewerCity,
      fallback,
    },
    radiusKm,
    count: people.length,
    people,
  });
}
