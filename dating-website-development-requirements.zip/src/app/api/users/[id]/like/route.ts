import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { likes, messages } from "@/db/schema";
import { requireMember } from "@/lib/api";
import { fail, ok, readJson } from "@/lib/api";
import { otherMemberExists } from "@/lib/verification";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireMember();
  if (!session.user) return session.error;
  const { id } = await params;
  const targetId = Number(id);
  if (!Number.isInteger(targetId)) return fail("Profile not found.", 404);

  const body = await readJson<{ action?: string }>(request);
  const action = body?.action === "pass" ? "pass" : "like";

  const target = await otherMemberExists(session.user.id, targetId);
  if (!target) return fail("This profile is no longer available.", 404);
  if (target.status !== "active") return fail("This profile is under review.", 403);

  await db
    .insert(likes)
    .values({ fromUserId: session.user.id, toUserId: targetId, action })
    .onConflictDoUpdate({
      target: [likes.fromUserId, likes.toUserId],
      set: { action, createdAt: new Date() },
    });

  let matched = false;
  if (action === "like") {
    const back = await db
      .select()
      .from(likes)
      .where(
        and(
          eq(likes.fromUserId, targetId),
          eq(likes.toUserId, session.user.id),
          eq(likes.action, "like"),
        ),
      )
      .limit(1);
    matched = back.length > 0;
    if (matched) {
      const already = await db
        .select({ id: messages.id })
        .from(messages)
        .where(
          and(eq(messages.senderId, targetId), eq(messages.receiverId, session.user.id)),
        )
        .limit(1);
      if (already.length === 0) {
        await db.insert(messages).values({
          senderId: targetId,
          receiverId: session.user.id,
          body: `You and ${target.fullName.split(" ")[0]} liked each other. Say hello 👋`,
        });
      }
    }
  }

  return ok({
    ok: true,
    action,
    matched,
    message: matched
      ? "It's a match! Chat is now unlocked."
      : action === "like"
        ? "Like sent. You'll be able to chat when they like you back."
        : "Profile passed.",
  });
}
