import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { likes, reports } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { haversineKm } from "@/lib/geo";
import { otherMemberExists, toPublicProfile } from "@/lib/verification";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const targetId = Number(id);
  if (!Number.isInteger(targetId)) return fail("Profile not found.", 404);

  const viewer = await getSessionUser();
  const target = await otherMemberExists(viewer?.id ?? 0, targetId);
  if (!target) return fail("This profile is no longer available.", 404);

  const viewerMember = viewer ? hasActiveMembership(viewer) : false;
  let youLiked = false;
  let likedYou = false;
  let match = false;
  let openReports = 0;

  if (viewer) {
    const myLike = await db
      .select()
      .from(likes)
      .where(and(eq(likes.fromUserId, viewer.id), eq(likes.toUserId, targetId)))
      .limit(1);
    const theirLike = await db
      .select()
      .from(likes)
      .where(and(eq(likes.fromUserId, targetId), eq(likes.toUserId, viewer.id)))
      .limit(1);
    youLiked = myLike[0]?.action === "like";
    likedYou = theirLike[0]?.action === "like";
    match = youLiked && likedYou;
  }

  const reportRows = await db
    .select({ id: reports.id })
    .from(reports)
    .where(and(eq(reports.reportedUserId, targetId), eq(reports.status, "open")));
  openReports = reportRows.length;

  const coordsKnown = target.lat !== null && target.lng !== null;
  const origin = viewer?.lat != null && viewer?.lng != null ? viewer : null;
  const distanceKm =
    coordsKnown && origin && target.lat !== null && target.lng !== null
      ? haversineKm(origin.lat!, origin.lng!, target.lat, target.lng)
      : null;

  const profile = toPublicProfile(target, {
    viewer,
    distanceKm,
    contactUnlocked: match,
  });

  return ok({
    profile,
    viewer: {
      signedIn: Boolean(viewer),
      isMember: viewerMember,
      isSelf: viewer?.id === targetId,
    },
    interaction: { youLiked, likedYou, match, canChat: match && viewerMember },
    safety: { openReports },
    online: target.lastActiveAt
      ? Date.now() - new Date(target.lastActiveAt).getTime() < 15 * 60 * 1000
      : false,
  });
}
