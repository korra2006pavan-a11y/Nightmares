import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { reports, users } from "@/db/schema";
import { fail, ok, readJson, requireUser } from "@/lib/api";
import { refreshTrust } from "@/lib/verification";

const REASONS = [
  "Fake photos / not the person in pictures",
  "Asking for money",
  "Abusive or threatening",
  "Spam / advertising",
  "Underage",
  "Something else",
];

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await requireUser();
  if (!session.user) return session.error;
  const { id } = await params;
  const targetId = Number(id);
  if (!Number.isInteger(targetId) || targetId === session.user.id)
    return fail("Invalid profile.");

  const body = await readJson<{ reason?: string; details?: string }>(request);
  const reason = (body?.reason ?? "").trim();
  if (!REASONS.includes(reason)) return fail("Choose a reason for the report.");

  const [target] = await db.select().from(users).where(eq(users.id, targetId)).limit(1);
  if (!target) return fail("Profile not found.", 404);

  const existing = await db
    .select({ id: reports.id })
    .from(reports)
    .where(
      and(
        eq(reports.reporterId, session.user.id),
        eq(reports.reportedUserId, targetId),
        eq(reports.status, "open"),
      ),
    )
    .limit(1);
  if (existing.length > 0) return fail("You already have an open report on this profile.");

  await db.insert(reports).values({
    reporterId: session.user.id,
    reportedUserId: targetId,
    reason,
    details: (body?.details ?? "").slice(0, 800),
  });

  const score = await refreshTrust(targetId);
  return ok({
    ok: true,
    trustScore: score,
    message:
      "Report submitted. Our fake-profile detector reviews the profile and quarantines it after repeated reports.",
  });
}
