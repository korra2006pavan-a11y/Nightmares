import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { likes, users } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { haversineKm } from "@/lib/geo";
import { toPublicProfile } from "@/lib/verification";

export const dynamic = "force-dynamic";

export async function GET() {
  const viewer = await getSessionUser();
  if (!viewer) return fail("Sign in required.", 401);
  const isMember = hasActiveMembership(viewer);

  const outgoing = await db
    .select()
    .from(likes)
    .where(and(eq(likes.fromUserId, viewer.id), eq(likes.action, "like")));
  const incoming = await db
    .select()
    .from(likes)
    .where(and(eq(likes.toUserId, viewer.id), eq(likes.action, "like")));

  const likedIds = new Set(outgoing.map((l) => l.toUserId));
  const incomingIds = new Set(incoming.map((l) => l.fromUserId));
  const matchedIds = [...likedIds].filter((id) => incomingIds.has(id));
  const newLikeIds = [...incomingIds].filter((id) => !likedIds.has(id));
  const pendingIds = [...likedIds].filter((id) => !incomingIds.has(id));

  const allIds = Array.from(new Set([...matchedIds, ...newLikeIds, ...pendingIds]));
  const rows =
    allIds.length > 0
      ? await db.select().from(users).where(inArray(users.id, allIds))
      : [];

  const decorate = (id: number) => {
    const target = rows.find((r) => r.id === id);
    if (!target) return null;
    const distanceKm =
      viewer.lat != null && viewer.lng != null && target.lat != null && target.lng != null
        ? haversineKm(viewer.lat, viewer.lng, target.lat, target.lng)
        : null;
    return toPublicProfile(target, { viewer, distanceKm, contactUnlocked: true });
  };

  return ok({
    isMember,
    matches: matchedIds.map(decorate).filter(Boolean),
    likesYou: newLikeIds.map(decorate).filter(Boolean),
    pending: pendingIds.map(decorate).filter(Boolean),
    counts: {
      matches: matchedIds.length,
      likesYou: newLikeIds.length,
      pending: pendingIds.length,
    },
  });
}
