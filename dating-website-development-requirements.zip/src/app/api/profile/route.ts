import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, verifyPassword } from "@/lib/auth";
import {
  fail,
  ok,
  parseDataUrl,
  readJson,
  requireUser,
  saveMedia,
  serializeMe,
} from "@/lib/api";
import { CITIES } from "@/lib/geo";
import { refreshTrust } from "@/lib/verification";

type ProfileBody = {
  fullName?: string;
  bio?: string;
  city?: string;
  area?: string;
  lookingFor?: string;
  interestedIn?: string;
  lat?: number | null;
  lng?: number | null;
  showPhoto?: boolean;
  showContact?: boolean;
  allowChatPhotos?: boolean;
  photo?: string;
  selfie?: string;
  currentPassword?: string;
  newPassword?: string;
  removePhoto?: boolean;
};

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await requireUser();
  if (!session.user) return session.error;
  return ok({ user: serializeMe(session.user) });
}

export async function PATCH(request: Request) {
  const session = await requireUser();
  if (!session.user) return session.error;
  const body = await readJson<ProfileBody>(request);
  if (!body) return fail("Invalid request body.");
  const user = session.user;
  const patch: Partial<typeof users.$inferInsert> = {};

  if (typeof body.fullName === "string" && body.fullName.trim().length >= 2) {
    patch.fullName = body.fullName.trim().slice(0, 80);
  }
  if (typeof body.bio === "string") patch.bio = body.bio.trim().slice(0, 600);
  if (typeof body.lookingFor === "string" && body.lookingFor.trim())
    patch.lookingFor = body.lookingFor.trim().slice(0, 40);
  if (body.interestedIn && ["male", "female", "any"].includes(body.interestedIn))
    patch.interestedIn = body.interestedIn;
  if (typeof body.showPhoto === "boolean") patch.showPhoto = body.showPhoto;
  if (typeof body.showContact === "boolean") patch.showContact = body.showContact;
  if (typeof body.allowChatPhotos === "boolean") patch.allowChatPhotos = body.allowChatPhotos;

  if (typeof body.city === "string" && body.city.trim()) {
    const preset = CITIES.find((c) => c.name.toLowerCase() === body.city!.trim().toLowerCase());
    patch.city = body.city.trim();
    if (preset && body.lat == null) {
      patch.lat = preset.lat;
      patch.lng = preset.lng;
    }
  }
  if (typeof body.area === "string") patch.area = body.area.trim().slice(0, 120);
  if (body.lat != null && body.lng != null) {
    const lat = Number(body.lat);
    const lng = Number(body.lng);
    if (Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
      patch.lat = lat;
      patch.lng = lng;
    }
  }

  if (typeof body.photo === "string") {
    const image = parseDataUrl(body.photo);
    if (!image) return fail("Photo must be a JPG/PNG/WebP under 3.5 MB.");
    patch.photoMediaId = await saveMedia(user.id, "photo", image);
  }
  if (typeof body.selfie === "string") {
    const image = parseDataUrl(body.selfie);
    if (!image) return fail("Selfie must be a JPG/PNG/WebP under 3.5 MB.");
    patch.selfieMediaId = await saveMedia(user.id, "selfie", image);
  }
  if (body.removePhoto) {
    patch.photoMediaId = null;
    patch.photoUrl = null;
  }

  if (body.newPassword) {
    if (body.newPassword.length < 8) return fail("New password must be at least 8 characters.");
    if (!body.currentPassword || !verifyPassword(body.currentPassword, user.passwordHash))
      return fail("Current password is incorrect.");
    patch.passwordHash = hashPassword(body.newPassword);
  }

  if (Object.keys(patch).length === 0) return fail("Nothing to update.");

  await db.update(users).set(patch).where(eq(users.id, user.id));
  await refreshTrust(user.id);
  const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  return ok({ user: serializeMe(fresh), message: "Saved." });
}
