import { getSessionUser, touchUser } from "@/lib/auth";
import { ok, serializeMe } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user || user.status === "banned") return ok({ user: null });
  await touchUser(user.id);
  return ok({ user: serializeMe(user) });
}
