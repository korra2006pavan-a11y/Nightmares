import { and, eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { otps, users } from "@/db/schema";
import { createSession, generateOtp, hashPassword } from "@/lib/auth";
import { fail, ok, parseDataUrl, readJson, saveMedia, serializeMe } from "@/lib/api";
import { ensureSeeded } from "@/lib/seed";
import { refreshTrust } from "@/lib/verification";

type SignupBody = {
  loginId?: string;
  email?: string;
  phone?: string;
  password?: string;
  fullName?: string;
  gender?: string;
  interestedIn?: string;
  birthYear?: number | string;
  city?: string;
  area?: string;
  bio?: string;
  lookingFor?: string;
  lat?: number | null;
  lng?: number | null;
  photo?: string;
  selfie?: string;
};

const GENDERS = ["female", "male", "other"];

export async function POST(request: Request) {
  await ensureSeeded();
  const body = await readJson<SignupBody>(request);
  if (!body) return fail("Invalid request body.");

  const email = (body.email ?? "").trim().toLowerCase();
  const phone = (body.phone ?? "").replace(/[^\d]/g, "").replace(/^91(?=\d{10}$)/, "");
  const loginId = (body.loginId ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  const fullName = (body.fullName ?? "").trim();
  const gender = (body.gender ?? "").trim();
  const interestedIn = (body.interestedIn ?? "any").trim();
  const birthYear = Number(body.birthYear);
  const city = (body.city ?? "").trim();
  const area = (body.area ?? "").trim();
  const bio = (body.bio ?? "").trim().slice(0, 600);
  const lookingFor = (body.lookingFor ?? "Long-term").trim();
  const lat = body.lat != null && Number.isFinite(Number(body.lat)) ? Number(body.lat) : null;
  const lng = body.lng != null && Number.isFinite(Number(body.lng)) ? Number(body.lng) : null;

  if (!/^[a-z0-9_]{3,20}$/.test(loginId))
    return fail("Login ID must be 3–20 characters: lowercase letters, numbers or underscore.");
  if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) return fail("Enter a valid email address.");
  if (!/^\d{10}$/.test(phone)) return fail("Enter a valid 10-digit Indian mobile number.");
  if (password.length < 8) return fail("Password must be at least 8 characters.");
  if (fullName.length < 2) return fail("Please enter your full name.");
  if (!GENDERS.includes(gender)) return fail("Select your gender.");
  const age = new Date().getFullYear() - birthYear;
  if (!Number.isFinite(birthYear) || age < 18 || age > 80)
    return fail("You must be 18 or older to join Milap.");
  if (!city) return fail("Select your city so we can show people near you.");

  const photo = parseDataUrl(body.photo);
  if (body.photo && !photo) return fail("Profile photo must be a JPG/PNG/WebP under 3.5 MB.");
  const selfie = parseDataUrl(body.selfie);
  if (body.selfie && !selfie) return fail("Selfie must be a JPG/PNG/WebP under 3.5 MB.");

  const clash = await db
    .select({ email: users.email, phone: users.phone, loginId: users.loginId })
    .from(users)
    .where(or(eq(users.email, email), eq(users.phone, phone), eq(users.loginId, loginId)))
    .limit(1);

  if (clash.length > 0) {
    const row = clash[0];
    if (row.email === email) return fail("This email is already registered. Please sign in.");
    if (row.phone === phone) return fail("This mobile number is already registered.");
    return fail("That login ID is taken. Try another one.");
  }

  const [created] = await db
    .insert(users)
    .values({
      loginId,
      email,
      phone,
      passwordHash: hashPassword(password),
      fullName,
      gender,
      interestedIn: GENDERS.includes(interestedIn) ? interestedIn : "any",
      birthYear,
      city,
      area,
      bio: bio || "New on Milap.",
      lookingFor,
      lat,
      lng,
      membershipStatus: "pending",
      trustScore: 0,
    })
    .returning();

  const patch: Partial<typeof users.$inferInsert> = {};
  if (photo) patch.photoMediaId = await saveMedia(created.id, "photo", photo);
  if (selfie) patch.selfieMediaId = await saveMedia(created.id, "selfie", selfie);
  if (Object.keys(patch).length > 0) {
    await db.update(users).set(patch).where(eq(users.id, created.id));
  }

  const emailCode = generateOtp();
  const phoneCode = generateOtp();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  await db.insert(otps).values([
    { userId: created.id, channel: "email", code: emailCode, expiresAt },
    { userId: created.id, channel: "phone", code: phoneCode, expiresAt },
  ]);

  await refreshTrust(created.id);
  await createSession(created.id);
  await db
    .update(users)
    .set({ lastActiveAt: sql`now()` })
    .where(eq(users.id, created.id));

  const [fresh] = await db.select().from(users).where(eq(users.id, created.id)).limit(1);

  return ok({
    user: serializeMe(fresh),
    demoCodes: { email: emailCode, phone: phoneCode },
    message: "Account created. Verify your email and mobile to unlock payment.",
  });
}
