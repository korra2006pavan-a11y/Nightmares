import { and, desc, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { otps, users } from "@/db/schema";
import { generateOtp } from "@/lib/auth";
import { fail, ok, readJson, requireUser, serializeMe } from "@/lib/api";
import { refreshTrust } from "@/lib/verification";

type Channel = "email" | "phone";

function normalizeChannel(value: unknown): Channel | null {
  return value === "email" || value === "phone" ? value : null;
}

/** Request a new OTP for email or mobile. */
export async function POST(request: Request) {
  const session = await requireUser();
  if (!session.user) return session.error;
  const body = await readJson<{ channel?: string }>(request);
  const channel = normalizeChannel(body?.channel);
  if (!channel) return fail("Choose email or mobile OTP.");

  const user = session.user;
  if (
    (channel === "email" && user.emailVerifiedAt) ||
    (channel === "phone" && user.phoneVerifiedAt)
  ) {
    return fail(`Your ${channel} is already verified.`);
  }

  const recent = await db
    .select({ createdAt: otps.createdAt })
    .from(otps)
    .where(
      and(eq(otps.userId, user.id), eq(otps.channel, channel), gt(otps.createdAt, new Date(Date.now() - 15_000))),
    )
    .limit(1);
  if (recent.length > 0) return fail("Please wait 15 seconds before requesting another OTP.", 429);

  const code = generateOtp();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  await db.insert(otps).values({ userId: user.id, channel, code, expiresAt });

  // No SMS/email provider is configured in this environment: the code is
  // returned to the client so the flow is fully testable end-to-end.
  return ok({
    sent: true,
    channel,
    devCode: code,
    destination: channel === "email" ? user.email : `+91 ${user.phone}`,
    expiresInSeconds: 600,
    message: "Demo mode: no SMS gateway connected, so the OTP is shown here.",
  });
}

/** Confirm the OTP and mark the channel verified. */
export async function PUT(request: Request) {
  const session = await requireUser();
  if (!session.user) return session.error;
  const body = await readJson<{ channel?: string; code?: string }>(request);
  const channel = normalizeChannel(body?.channel);
  const code = (body?.code ?? "").trim();
  if (!channel) return fail("Choose email or mobile OTP.");
  if (!/^\d{6}$/.test(code)) return fail("Enter the 6-digit OTP.");

  const rows = await db
    .select()
    .from(otps)
    .where(
      and(
        eq(otps.userId, session.user.id),
        eq(otps.channel, channel),
        eq(otps.code, code),
        isNull(otps.consumedAt),
        gt(otps.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(otps.createdAt))
    .limit(1);

  if (rows.length === 0) {
    return fail("That OTP is incorrect or expired. Request a new one.", 400);
  }

  await db.update(otps).set({ consumedAt: new Date() }).where(eq(otps.id, rows[0].id));
  await db
    .update(users)
    .set(
      channel === "email"
        ? { emailVerifiedAt: new Date() }
        : { phoneVerifiedAt: new Date() },
    )
    .where(eq(users.id, session.user.id));
  await refreshTrust(session.user.id);

  const [fresh] = await db.select().from(users).where(eq(users.id, session.user.id)).limit(1);
  return ok({
    verified: true,
    channel,
    user: serializeMe(fresh),
    message: `${channel === "email" ? "Email" : "Mobile number"} verified.`,
  });
}
