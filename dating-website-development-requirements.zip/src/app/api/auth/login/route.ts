import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, verifyPassword } from "@/lib/auth";
import { fail, ok, readJson, serializeMe } from "@/lib/api";
import { ensureSeeded } from "@/lib/seed";
import { refreshTrust } from "@/lib/verification";

type LoginBody = { identifier?: string; password?: string };

export async function POST(request: Request) {
  await ensureSeeded();
  const body = await readJson<LoginBody>(request);
  const identifier = (body?.identifier ?? "").trim().toLowerCase();
  const password = body?.password ?? "";
  if (!identifier || !password) return fail("Enter your login ID/email and password.");

  const digits = identifier.replace(/[^\d]/g, "").replace(/^91(?=\d{10}$)/, "");
  const rows = await db
    .select()
    .from(users)
    .where(
      or(
        eq(users.email, identifier),
        eq(users.loginId, identifier),
        ...(digits.length === 10 ? [eq(users.phone, digits)] : []),
      ),
    )
    .limit(1);

  const user = rows[0];
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return fail("Invalid login ID or password.", 401);
  }
  if (user.status === "banned") {
    return fail(
      user.statusReason || "This account was removed for violating Milap's safety policy.",
      403,
    );
  }

  await createSession(user.id);
  await db.update(users).set({ lastActiveAt: new Date() }).where(eq(users.id, user.id));
  if (user.role !== "admin") await refreshTrust(user.id);

  return ok({ user: serializeMe(user), redirect: user.role === "admin" ? "/admin" : "/app" });
}
