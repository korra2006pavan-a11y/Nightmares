"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatDistance } from "@/lib/geo";
import { apiFetch } from "@/lib/image";
import type { MatchData, Person } from "@/lib/types";

type Tab = "matches" | "likesYou" | "pending";

export default function MatchesPage() {
  const [data, setData] = useState<MatchData | null>(null);
  const [tab, setTab] = useState<Tab>("matches");
  const [toast, setToast] = useState("");

  async function load() {
    try {
      setData(await apiFetch<MatchData>("/api/matches"));
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Could not load matches.");
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function likeBack(person: Person) {
    try {
      const result = await apiFetch<{ message: string }>(`/api/users/${person.id}/like`, {
        method: "POST",
        body: JSON.stringify({ action: "like" }),
      });
      setToast(result.message);
      await load();
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Could not like back.");
    }
  }

  const lists: Record<Tab, Person[]> = {
    matches: data?.matches ?? [],
    likesYou: data?.likesYou ?? [],
    pending: data?.pending ?? [],
  };

  return (
    <div>
      <p className="text-[11px] uppercase tracking-[0.2em] text-cream/40">Connections</p>
      <h1 className="display mt-1 text-3xl sm:text-4xl">Your matches</h1>
      <p className="mt-1 text-[12px] text-cream/50">
        A mutual like unlocks chat, photo sharing and (if they allow it) the phone number.
      </p>

      {toast && (
        <p className="mt-4 rounded-xl border border-white/12 bg-white/[0.05] px-3 py-2 text-[12px] text-cream/75">
          {toast}
        </p>
      )}

      <div className="mt-5 flex gap-2 overflow-x-auto no-scrollbar">
        {(
          [
            ["matches", "Matches", data?.counts.matches ?? 0],
            ["likesYou", "Likes you", data?.counts.likesYou ?? 0],
            ["pending", "You liked", data?.counts.pending ?? 0],
          ] as [Tab, string, number][]
        ).map(([key, label, count]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`shrink-0 rounded-full border px-4 py-2 text-[12px] transition ${
              tab === key
                ? "border-rose/50 bg-rose/15 text-rose"
                : "border-white/12 bg-white/[0.04] text-cream/60 hover:text-cream"
            }`}
          >
            {label}
            <span className="ml-1.5 rounded-full bg-black/30 px-1.5 py-0.5 text-[10px]">{count}</span>
          </button>
        ))}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {lists[tab].map((person) => (
          <div key={person.id} className="card flex gap-3 p-3">
            <Link
              href={`/app/profile/${person.id}`}
              className="relative h-24 w-20 shrink-0 overflow-hidden rounded-xl bg-ink-soft"
            >
              {person.photoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={person.photoUrl} alt={person.fullName} className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-lg">🔒</div>
              )}
            </Link>
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-[14px] font-semibold">
                    {person.firstName}, {person.age}
                  </p>
                  <p className="truncate text-[11px] text-cream/45">
                    {formatDistance(person.distanceKm)} · {person.area || person.city}
                  </p>
                </div>
                {person.identityVerified && <span className="badge-verified">✓</span>}
              </div>
              <p className="mt-1 line-clamp-2 text-[11px] text-cream/50">{person.bio}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {tab === "matches" && (
                  <>
                    <Link href={`/app/chat/${person.id}`} className="btn-mint btn-sm">💬 Chat</Link>
                    <Link href={`/app/profile/${person.id}`} className="btn-ghost btn-sm">Profile</Link>
                  </>
                )}
                {tab === "likesYou" && (
                  <>
                    <button className="btn-primary btn-sm" onClick={() => likeBack(person)}>
                      ♥ Like back
                    </button>
                    <Link href={`/app/profile/${person.id}`} className="btn-ghost btn-sm">View</Link>
                  </>
                )}
                {tab === "pending" && (
                  <>
                    <span className="badge-muted">waiting for their like</span>
                    <Link href={`/app/profile/${person.id}`} className="btn-ghost btn-sm">View</Link>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {lists[tab].length === 0 && (
        <div className="card mt-4 p-10 text-center">
          <p className="text-3xl">{tab === "matches" ? "💞" : tab === "likesYou" ? "✨" : "📨"}</p>
          <h3 className="display mt-3 text-xl">
            {tab === "matches"
              ? "No matches yet"
              : tab === "likesYou"
                ? "Nobody has liked you yet"
                : "You haven't liked anyone yet"}
          </h3>
          <p className="mx-auto mt-2 max-w-sm text-[12px] text-cream/50">
            {tab === "matches"
              ? "Send likes to people nearby. When the feeling is mutual, chat unlocks instantly."
              : "Keep your profile complete and verified — complete profiles get far more likes."}
          </p>
          <Link href="/app" className="btn-primary btn-sm mt-4 inline-flex">Discover people</Link>
        </div>
      )}

      {data && !data.isMember && (
        <div className="mt-4 rounded-2xl border border-rose/30 bg-rose/[0.08] p-4 text-[12px]">
          <p className="font-semibold text-rose">Membership inactive</p>
          <p className="text-cream/55">
            Likes and chat needs an active ₹99 plan.{" "}
            <Link href="/app/membership" className="underline">Activate with a UTR now →</Link>
          </p>
        </div>
      )}
    </div>
  );
}
