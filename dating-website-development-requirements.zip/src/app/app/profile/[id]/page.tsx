"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { formatDistance } from "@/lib/geo";
import { apiFetch } from "@/lib/image";
import type { ProfileDetail } from "@/lib/types";

const REASONS = [
  "Fake photos / not the person in pictures",
  "Asking for money",
  "Abusive or threatening",
  "Spam / advertising",
  "Underage",
  "Something else",
];

export default function ProfilePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params?.id;
  const [data, setData] = useState<ProfileDetail | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState(REASONS[0]);
  const [details, setDetails] = useState("");

  const load = useCallback(async () => {
    try {
      const result = await apiFetch<ProfileDetail>(`/api/users/${id}`);
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Profile unavailable.");
    }
  }, [id]);

  useEffect(() => {
    if (id) void load();
  }, [id, load]);

  async function act(action: "like" | "pass") {
    try {
      const result = await apiFetch<{ message: string }>(`/api/users/${id}/like`, {
        method: "POST",
        body: JSON.stringify({ action }),
      });
      setToast(result.message);
      await load();
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Action failed.");
    }
  }

  async function submitReport() {
    try {
      const result = await apiFetch<{ message: string }>(`/api/users/${id}/report`, {
        method: "POST",
        body: JSON.stringify({ reason, details }),
      });
      setReportOpen(false);
      setDetails("");
      setToast(result.message);
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Could not submit report.");
    }
  }

  if (error) {
    return (
      <div className="card p-8 text-center">
        <p className="text-3xl">🚫</p>
        <h1 className="display mt-2 text-2xl">{error}</h1>
        <Link href="/app" className="btn-ghost btn-sm mt-4 inline-flex">Back to discovery</Link>
      </div>
    );
  }

  if (!data) {
    return <p className="py-20 text-center text-sm text-cream/40">Loading profile…</p>;
  }

  const { profile, interaction, viewer } = data;

  return (
    <div>
      <button onClick={() => router.back()} className="text-[12px] text-cream/45 hover:text-cream">
        ← Back
      </button>

      {toast && (
        <p className="mt-3 rounded-xl border border-white/12 bg-white/[0.05] px-3 py-2 text-[12px] text-cream/75">
          {toast}
        </p>
      )}

      <div className="mt-4 grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="card overflow-hidden">
          <div className="relative aspect-[4/5] bg-ink-soft">
            {profile.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={profile.photoUrl}
                alt={profile.fullName}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="grid h-full place-items-center bg-gradient-to-br from-ink-soft to-black text-center">
                <div>
                  <p className="text-4xl">🔒</p>
                  <p className="mt-3 max-w-[220px] px-4 text-[11px] uppercase tracking-widest text-cream/35">
                    {profile.photoHiddenByUser
                      ? "This member keeps their photos private"
                      : "Photos unlock with your ₹99 membership"}
                  </p>
                  {!viewer.isMember && !profile.photoHiddenByUser && (
                    <Link href="/app/membership" className="btn-primary btn-sm mt-4 inline-flex">
                      Become a member
                    </Link>
                  )}
                </div>
              </div>
            )}
            <div className="absolute inset-x-0 top-0 flex justify-between p-3">
              {profile.identityVerified ? (
                <span className="badge-verified">✓ identity verified</span>
              ) : (
                <span className="badge-warn">verification pending</span>
              )}
              {data.online && (
                <span className="flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[9px] text-mint">
                  <span className="live-dot h-1.5 w-1.5 rounded-full bg-mint" /> online
                </span>
              )}
            </div>
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-4">
              <h1 className="display text-2xl">
                {profile.fullName}, {profile.age}
              </h1>
              <p className="text-[12px] text-cream/65">
                {formatDistance(profile.distanceKm)} · {profile.area || profile.city}
              </p>
            </div>
          </div>
          <div className="grid grid-cols-3 divide-x divide-white/10 border-t border-white/10 text-center">
            {[
              ["Trust", `${profile.trustScore}/100`],
              ["Since", new Date(profile.memberSince).getFullYear().toString()],
              ["Wants", profile.lookingFor],
            ].map(([label, value]) => (
              <div key={label} className="px-2 py-3">
                <p className="text-[9px] uppercase tracking-widest text-cream/35">{label}</p>
                <p className="mt-0.5 truncate text-[12px] font-medium">{value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip">{profile.gender === "female" ? "Woman" : profile.gender === "male" ? "Man" : "Other"}</span>
              <span className="chip">Looking for {profile.lookingFor.toLowerCase()}</span>
              {profile.isPremium && <span className="badge-verified">paid member</span>}
              {interaction.likedYou && <span className="badge-warn">liked you</span>}
              {interaction.match && <span className="badge-danger">you matched</span>}
            </div>
            <h2 className="mt-4 text-[11px] uppercase tracking-widest text-cream/35">About</h2>
            <p className="mt-1 text-[13px] leading-relaxed text-cream/70">{profile.bio}</p>
          </div>

          {/* Contact privacy */}
          <div className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold">Contact details</h2>
              <span className={profile.contactPhone ? "badge-verified" : "badge-muted"}>
                {profile.contactPhone ? "revealed" : "private"}
              </span>
            </div>
            {profile.contactPhone ? (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <a href={`tel:+91${profile.contactPhone}`} className="btn-mint btn-sm">
                  📞 +91 {profile.contactPhone}
                </a>
                <a
                  href={`https://wa.me/91${profile.contactPhone}`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-ghost btn-sm"
                >
                  WhatsApp
                </a>
              </div>
            ) : profile.contactLocked ? (
              <p className="mt-2 text-[12px] leading-relaxed text-cream/50">
                {profile.firstName} shares their number only after a mutual like. Send a like — if
                they like you back, the number appears here.
              </p>
            ) : profile.showContact ? (
              <p className="mt-2 text-[12px] text-cream/50">
                Number unlocks with an active ₹99 membership.
              </p>
            ) : (
              <p className="mt-2 text-[12px] text-cream/50">
                {profile.firstName} has chosen to keep their number private. Chat inside Milap
                instead — it is safer and moderated.
              </p>
            )}
            {!viewer.isMember && (
              <Link href="/app/membership" className="btn-primary btn-sm mt-3 inline-flex">
                Unlock contact &amp; photos · ₹99
              </Link>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button className="btn-primary" onClick={() => act("like")} disabled={!viewer.isMember}>
              {interaction.youLiked ? "♥ Liked" : "♥ Send a like"}
            </button>
            {interaction.canChat ? (
              <Link href={`/app/chat/${profile.id}`} className="btn-mint text-center">
                💬 Chat now
              </Link>
            ) : (
              <button className="btn-ghost" disabled title="Chat unlocks on a mutual like">
                🔒 Chat locked
              </button>
            )}
            <button className="btn-ghost" onClick={() => act("pass")}>
              Pass
            </button>
            <button className="btn-ghost text-rose" onClick={() => setReportOpen(true)}>
              ⚠ Report / fake
            </button>
          </div>

          <div className="card p-4 text-[11.5px] leading-relaxed text-cream/50">
            <p className="mb-1 font-semibold text-cream/70">Safety first</p>
            Never send money or OTPs to anyone you meet here. Meet in a public place for the first
            few times, and tell a friend where you are going. Report anything that feels wrong —
            repeated reports quarantine the profile automatically.
          </div>
        </div>
      </div>

      {reportOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
          <div className="card-solid w-full max-w-md p-5">
            <h3 className="display text-xl">Report {profile.firstName}</h3>
            <p className="mt-1 text-[11px] text-cream/45">
              Our admin team reviews every report. Three open reports quarantine an account until
              it is verified.
            </p>
            <div className="mt-4 space-y-2">
              {REASONS.map((item) => (
                <label key={item} className="flex cursor-pointer items-center gap-2 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-[12px]">
                  <input
                    type="radio"
                    name="reason"
                    checked={reason === item}
                    onChange={() => setReason(item)}
                    className="accent-rose"
                  />
                  {item}
                </label>
              ))}
            </div>
            <textarea
              className="input mt-3 min-h-20 resize-none"
              placeholder="Anything else the admin should know? (optional)"
              value={details}
              onChange={(e) => setDetails(e.target.value)}
            />
            <div className="mt-4 flex justify-end gap-2">
              <button className="btn-ghost btn-sm" onClick={() => setReportOpen(false)}>Cancel</button>
              <button className="btn-primary btn-sm" onClick={submitReport}>Submit report</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
