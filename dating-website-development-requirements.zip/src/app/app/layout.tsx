import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import { serializeMe } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function MemberLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role === "admin") redirect("/admin");
  if (user.status === "banned") redirect("/login");

  return <AppShell user={serializeMe(user)}>{children}</AppShell>;
}
