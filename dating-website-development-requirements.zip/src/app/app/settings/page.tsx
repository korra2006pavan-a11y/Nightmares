"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ImagePicker } from "@/components/ImagePicker";
import { CITIES } from "@/lib/geo";
import { apiFetch, getBrowserLocation } from "@/lib/image";
import type { Me } from "@/lib/types";

const LOOKING_FOR = ["Long-term", "Dating", "Hookup", "Friendship", "Marriage"];

export default function SettingsPage() {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [form, setForm] = useState({
    fullName: "",
    city: "",
    area: "",
    bio: "",
    lookingFor: "Long-term",
    interestedIn: "any",
    showPhoto: true,
    showContact: false,
    allowChatPhotos: true,
  });
  const [photo, setPhoto] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);
  const [passwords, setPasswords] = useState({ currentPassword: "", newPassword: "" });
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await apiFetch<{ user: Me }>("/api/profile");
      setMe(data.user);
      setForm({
        fullName: data.user.fullName,
        city: data.user.city,
        area: data.user.area,
        bio: data.user.bio,
        lookingFor: data.user.lookingFor,
        interestedIn: data.user.interestedIn,
        showPhoto: data.user.showPhoto,
        showContact: data.user.showContact,
        allowChatPhotos: data.user.allowChatPhotos,
      });
    } catch (err) {
      setMessage({
        kind: "error",
        text: err instanceof Error ? err.message : "Could not load your profile.",
      });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function patch(payload: Record<string, unknown>, successText: string) {
    setBusy(true);
    setMessage(null);
    try {
      const data = await apiFetch<{ user: Me; message: string }>("/api/profile", {
        method: "PATCH",
        body: JSON.stringify(payload),
      });
      setMe(data.user);
      setMessage({ kind: "ok", text: successText });
      router.refresh();
    } catch (err) {
      setMessage({
        kind: "error",
        text: err instanceof Error ? err.message : "Could not save changes.",
      });
    } finally {
      setBusy(false);
    }
  }

  if (!me) return <p className="py-20 text-center text-sm text-cream/40">Loading settings…</p>;

  const checks = [
    ["Email verified", me.emailVerified],
    ["Mobile verified", me.phoneVerified],
    ["Selfie submitted", me.hasSelfie],
    ["Identity reviewed", me.identityVerified],
    ["Payment completed", me.isMember],
  ] as [string, boolean][];

  return (
    <div>
      <p className="text-[11px] uppercase tracking-[0.2em] text-cream/40">Account</p>
      <h1 className="display mt-1 text-3xl sm:text-4xl">Settings &amp; privacy</h1>

      {message && (
        <p
          className={`mt-4 rounded-xl border px-3 py-2 text-[12px] ${
            message.kind === "ok"
              ? "border-mint/30 bg-mint/10 text-mint"
              : "border-rose/30 bg-rose/10 text-rose"
          }`}
        >
          {message.text}
        </p>
      )}

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Verification &amp; trust</h2>
            <span className="badge-verified">score {me.trustScore}/100</span>
          </div>
          <div className="mt-3 space-y-1.5">
            {checks.map(([label, done]) => (
              <div key={label} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-3 py-1.5 text-[11.5px]">
                <span className="text-cream/55">{label}</span>
                <span className={done ? "text-mint" : "text-gold"}>{done ? "✓" : "pending"}</span>
              </div>
            ))}
          </div>
          {!me.isMember && (
            <Link href="/app/membership" className="btn-primary btn-sm mt-3 inline-flex">
              Activate ₹99 membership →
            </Link>
          )}
          {(!me.emailVerified || !me.phoneVerified || !me.hasSelfie) && (
            <Link href="/verify" className="btn-ghost btn-sm mt-2 inline-flex">
              Finish OTP verification
            </Link>
          )}
          <p className="mt-3 text-[11px] leading-relaxed text-cream/35">
            Login ID: <span className="text-cream/60">{me.loginId}</span> · Email: {me.email} ·
            Mobile: +91 {me.phone}
          </p>
        </div>

        <div className="card p-5">
          <h2 className="text-sm font-semibold">Privacy</h2>
          <p className="mt-1 text-[11px] text-cream/45">
            You control who sees your photos and your number.
          </p>
          <div className="mt-3 space-y-2">
            {(
              [
                ["showPhoto", "Show my photo to verified members", form.showPhoto],
                [
                  "showContact",
                  "Show my mobile number after a mutual like",
                  form.showContact,
                ],
                [
                  "allowChatPhotos",
                  "Allow sending photos inside chat",
                  form.allowChatPhotos,
                ],
              ] as [keyof typeof form, string, boolean][]
            ).map(([key, label, value]) => (
              <label
                key={key}
                className="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-[11.5px] text-cream/70"
              >
                {label}
                <span
                  className={`relative h-5 w-9 shrink-0 rounded-full transition ${
                    value ? "bg-mint/70" : "bg-white/15"
                  }`}
                >
                  <input
                    type="checkbox"
                    className="peer sr-only"
                    checked={value}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, [key]: e.target.checked }))
                    }
                  />
                  <span
                    className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${
                      value ? "left-4" : "left-0.5"
                    }`}
                  />
                </span>
              </label>
            ))}
          </div>
          <button
            className="btn-primary btn-sm mt-3"
            disabled={busy}
            onClick={() =>
              patch(
                {
                  showPhoto: form.showPhoto,
                  showContact: form.showContact,
                  allowChatPhotos: form.allowChatPhotos,
                },
                "Privacy preferences updated.",
              )
            }
          >
            Save privacy
          </button>
        </div>

        <div className="card p-5 lg:col-span-2">
          <h2 className="text-sm font-semibold">Profile</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label">Full name</label>
              <input
                className="input"
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Interested in</label>
              <select
                className="input"
                value={form.interestedIn}
                onChange={(e) => setForm({ ...form, interestedIn: e.target.value })}
              >
                <option value="male">Men</option>
                <option value="female">Women</option>
                <option value="any">Anyone</option>
              </select>
            </div>
            <div>
              <label className="label">City</label>
              <select
                className="input"
                value={form.city}
                onChange={(e) => setForm({ ...form, city: e.target.value })}
              >
                {!CITIES.some((c) => c.name === form.city) && (
                  <option value={form.city}>{form.city}</option>
                )}
                {CITIES.map((city) => (
                  <option key={city.name} value={city.name}>
                    {city.name}, {city.state}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Area</label>
              <input
                className="input"
                value={form.area}
                onChange={(e) => setForm({ ...form, area: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Looking for</label>
              <select
                className="input"
                value={form.lookingFor}
                onChange={(e) => setForm({ ...form, lookingFor: e.target.value })}
              >
                {LOOKING_FOR.map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="label">Bio</label>
              <textarea
                className="input min-h-24 resize-none"
                maxLength={600}
                value={form.bio}
                onChange={(e) => setForm({ ...form, bio: e.target.value })}
              />
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              className="btn-primary btn-sm"
              disabled={busy}
              onClick={() =>
                patch(
                  {
                    fullName: form.fullName,
                    city: form.city,
                    area: form.area,
                    bio: form.bio,
                    lookingFor: form.lookingFor,
                    interestedIn: form.interestedIn,
                  },
                  "Profile saved.",
                )
              }
            >
              Save profile
            </button>
            <button
              className="btn-ghost btn-sm"
              disabled={busy}
              onClick={async () => {
                try {
                  const coords = await getBrowserLocation();
                  await patch(coords, "Location updated — you will see closer members first.");
                } catch (err) {
                  setMessage({
                    kind: "error",
                    text: err instanceof Error ? err.message : "Location failed.",
                  });
                }
              }}
            >
              📍 Update location
            </button>
            <span className="chip">
              {me.lat != null ? `${me.lat.toFixed(3)}, ${me.lng?.toFixed(3)}` : "location not set"}
            </span>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="text-sm font-semibold">Photos</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <ImagePicker
              label="Profile photo"
              value={photo}
              onChange={setPhoto}
              hint="This is what members see. Use a recent, clear photo."
            />
            <ImagePicker
              label="Verification selfie"
              value={selfie}
              onChange={setSelfie}
              shape="circle"
              hint="Admin-only. Never shown to other members."
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              className="btn-primary btn-sm"
              disabled={busy || (!photo && !selfie)}
              onClick={() => {
                const payload: Record<string, unknown> = {};
                if (photo) payload.photo = photo;
                if (selfie) payload.selfie = selfie;
                void patch(payload, "Photos updated.").then(() => {
                  setPhoto(null);
                  setSelfie(null);
                });
              }}
            >
              Save photos
            </button>
            {me.photoUrl && (
              <button
                className="btn-ghost btn-sm text-rose"
                disabled={busy}
                onClick={() => void patch({ removePhoto: true }, "Profile photo removed.")}
              >
                Remove current photo
              </button>
            )}
          </div>
          <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
            {me.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={me.photoUrl} alt="Current profile" className="h-40 w-full object-cover" />
            ) : (
              <div className="grid h-40 place-items-center bg-black/30 text-[11px] text-cream/35">
                No profile photo — others cannot see you clearly
              </div>
            )}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="text-sm font-semibold">Password</h2>
          <p className="mt-1 text-[11px] text-cream/45">
            Login ID <span className="text-cream/70">{me.loginId}</span> · change your password any
            time.
          </p>
          <div className="mt-3 space-y-3">
            <div>
              <label className="label">Current password</label>
              <input
                type="password"
                className="input"
                value={passwords.currentPassword}
                onChange={(e) =>
                  setPasswords({ ...passwords, currentPassword: e.target.value })
                }
              />
            </div>
            <div>
              <label className="label">New password</label>
              <input
                type="password"
                className="input"
                value={passwords.newPassword}
                onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
              />
            </div>
            <button
              className="btn-primary btn-sm"
              disabled={busy || passwords.newPassword.length < 8}
              onClick={async () => {
                await patch(passwords, "Password changed.");
                setPasswords({ currentPassword: "", newPassword: "" });
              }}
            >
              Update password
            </button>
          </div>
          <p className="mt-4 rounded-xl border border-white/10 bg-black/25 p-3 text-[10.5px] leading-relaxed text-cream/35">
            Milap never asks for your password, OTP or UPI PIN. If someone claims to be support,
            report them immediately.
          </p>
        </div>
      </div>
    </div>
  );
}
