"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { formatDistance } from "@/lib/geo";
import { apiFetch, getBrowserLocation } from "@/lib/image";
import type { NearbyData, NearbyPerson } from "@/lib/types";

type Filters = {
  radius: number;
  gender: string;
  minAge: number;
  maxAge: number;
  verified: boolean;
  q: string;
};

const initialFilters: Filters = {
  radius: 60,
  gender: "any",
  minAge: 18,
  maxAge: 60,
  verified: false,
  q: "",
};

export default function DiscoverPage() {
  const [data, setData] = useState<NearbyData | null>(null);
  const [filters, setFilters] = useState<Filters>(initialFilters);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState("");
  const [locating, setLocating] = useState(false);

  const load = useCallback(async (next: Filters) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        radius: String(next.radius),
        gender: next.gender,
        minAge: String(next.minAge),
        maxAge: String(next.maxAge),
        verified: next.verified ? "1" : "0",
        q: next.q,
      });
      const result = await apiFetch<NearbyData>(`/api/nearby?${params.toString()}`);
      setData(result);
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Could not load people near you.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => void load(filters), 250);
    return () => clearTimeout(timer);
  }, [filters, load]);

  async function updateLocation() {
    setLocating(true);
    setToast("");
    try {
      const coords = await getBrowserLocation();
      await apiFetch("/api/profile", {
        method: "PATCH",
        body: JSON.stringify(coords),
      });
      setToast("Location updated — showing the nearest members first.");
      await load(filters);
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Location update failed.");
    } finally {
      setLocating(false);
    }
  }

  async function act(person: NearbyPerson, action: "like" | "pass") {
    try {
      const result = await apiFetch<{ message: string; matched: boolean }>(
        `/api/users/${person.id}/like`,
        { method: "POST", body: JSON.stringify({ action }) },
      );
      setToast(result.message);
      setData((prev) =>
        prev
          ? {
              ...prev,
              people: prev.people.map((p) =>
                p.id === person.id
                  ? { ...p, youLiked: action === "like", isMatch: result.matched }
                  : p,
              ),
            }
          : prev,
      );
    } catch (err) {
      setToast(err instanceof Error ? err.message : "Could not save that action.");
    }
  }

  const isMember = data?.isMember ?? false;
  const people = data?.people ?? [];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-cream/40">Discover</p>
          <h1 className="display mt-1 text-3xl sm:text-4xl">People near you</h1>
          <p className="mt-1 text-[12px] text-cream/50">
            {data?.origin ? (
              <>
                Ranking from <span className="text-cream/80">{data.origin.label}</span>
                {data.origin.fallback && " (city centre — add precise location for sharper results)"}
              </>
            ) : (
              "Find verified singles around your area."
            )}
          </p>
        </div>
        <button className="btn-ghost btn-sm" onClick={updateLocation} disabled={locating}>
          {locating ? "Locating…" : "📍 Update my location"}
        </button>
      </div>

      {!isMember && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-rose/30 bg-rose/[0.09] p-4">
          <div className="text-[12px] leading-relaxed text-cream/75">
            <p className="font-semibold text-rose">Photos are locked — membership not active.</p>
            <p className="text-cream/55">
              Pay ₹99 to the admin UPI ID, upload the screenshot and UTR, and the checker unlocks
              every profile instantly.
            </p>
          </div>
          <Link href="/app/membership" className="btn-primary btn-sm">Unlock for ₹99 →</Link>
        </div>
      )}

      {toast && (
        <p className="mt-4 rounded-xl border border-white/12 bg-white/[0.05] px-3 py-2 text-[12px] text-cream/75">
          {toast}
        </p>
      )}

      {/* Filters */}
      <div className="card mt-5 p-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div>
            <label className="label">Within {filters.radius} km</label>
            <input
              type="range"
              min={1}
              max={300}
              step={1}
              value={filters.radius}
              onChange={(e) => setFilters({ ...filters, radius: Number(e.target.value) })}
              className="w-full accent-rose"
            />
          </div>
          <div>
            <label className="label">Show</label>
            <select
              className="input py-2"
              value={filters.gender}
              onChange={(e) => setFilters({ ...filters, gender: e.target.value })}
            >
              <option value="any">Everyone</option>
              <option value="female">Women</option>
              <option value="male">Men</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label className="label">Age {filters.minAge}–{filters.maxAge}</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min={18}
                max={80}
                value={filters.minAge}
                onChange={(e) => setFilters({ ...filters, minAge: Number(e.target.value) })}
                className="input py-2"
              />
              <input
                type="number"
                min={18}
                max={80}
                value={filters.maxAge}
                onChange={(e) => setFilters({ ...filters, maxAge: Number(e.target.value) })}
                className="input py-2"
              />
            </div>
          </div>
          <div>
            <label className="label">Search</label>
            <input
              className="input py-2"
              placeholder="City, area, interest…"
              value={filters.q}
              onChange={(e) => setFilters({ ...filters, q: e.target.value })}
            />
          </div>
          <div className="flex items-end">
            <label className="flex w-full cursor-pointer items-center justify-between gap-2 rounded-2xl border border-white/12 bg-black/25 px-3 py-2.5 text-[12px] text-cream/70">
              Identity verified only
              <input
                type="checkbox"
                checked={filters.verified}
                onChange={(e) => setFilters({ ...filters, verified: e.target.checked })}
                className="h-4 w-4 accent-mint"
              />
            </label>
          </div>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <p className="text-[12px] text-cream/45">
          {loading ? "Scanning nearby profiles…" : `${people.length} verified profiles match`}
        </p>
        <Link href="/app/matches" className="text-[12px] text-rose hover:underline">
          View your matches →
        </Link>
      </div>

      <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {people.map((person) => (
          <article key={person.id} className="card overflow-hidden">
            <Link href={`/app/profile/${person.id}`} className="relative block aspect-[4/5] overflow-hidden bg-ink-soft">
              {person.photoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={person.photoUrl}
                  alt={person.fullName}
                  className="h-full w-full object-cover transition duration-500 hover:scale-[1.03]"
                />
              ) : (
                <div className="grid h-full w-full place-items-center bg-gradient-to-br from-ink-soft to-black">
                  <div className="text-center">
                    <p className="text-3xl">🔒</p>
                    <p className="mt-2 px-6 text-[10px] uppercase tracking-widest text-cream/35">
                      {person.photoHiddenByUser
                        ? "This member keeps photos private"
                        : "Photo unlocks with membership"}
                    </p>
                  </div>
                </div>
              )}
              <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
                <div className="flex flex-wrap gap-1.5">
                  {person.identityVerified && <span className="badge-verified">✓ verified</span>}
                  {person.likedYou && <span className="badge-warn">liked you</span>}
                  {person.isMatch && <span className="badge-danger">match</span>}
                </div>
                {person.lastActive &&
                  Date.now() - new Date(person.lastActive).getTime() < 15 * 60 * 1000 && (
                    <span className="flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[9px] text-mint">
                      <span className="live-dot h-1.5 w-1.5 rounded-full bg-mint" /> online
                    </span>
                  )}
              </div>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent p-3">
                <p className="text-[15px] font-semibold">
                  {person.firstName}, {person.age}
                </p>
                <p className="text-[11px] text-cream/60">
                  {formatDistance(person.distanceKm)} · {person.area || person.city}
                </p>
              </div>
            </Link>

            <div className="p-3">
              <p className="line-clamp-2 min-h-8 text-[11.5px] leading-relaxed text-cream/55">
                {person.bio}
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <span className="chip text-[10px]">{person.lookingFor}</span>
                <span className="chip text-[10px]">trust {person.trustScore}</span>
                {person.showContact ? (
                  <span className="chip text-[10px] text-mint">number on request</span>
                ) : (
                  <span className="chip text-[10px]">number private</span>
                )}
              </div>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => act(person, "like")}
                  disabled={!isMember}
                  className="btn-primary btn-sm flex-1"
                  title={isMember ? "Send a like" : "Membership required"}
                >
                  {person.youLiked ? "♥ Liked" : "♥ Like"}
                </button>
                <Link
                  href={`/app/profile/${person.id}`}
                  className="btn-ghost btn-sm flex-1 text-center"
                >
                  View
                </Link>
                <button
                  onClick={() => act(person, "pass")}
                  className="btn-ghost btn-sm px-3"
                  aria-label="Pass"
                >
                  ✕
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {!loading && people.length === 0 && (
        <div className="card mt-4 p-10 text-center">
          <p className="text-3xl">🫥</p>
          <h3 className="display mt-3 text-xl">No one in this radius yet</h3>
          <p className="mx-auto mt-2 max-w-sm text-[12px] text-cream/50">
            Try widening the distance, clearing the verified-only filter, or updating your
            location. New verified members join daily.
          </p>
          <button
            className="btn-ghost btn-sm mt-4"
            onClick={() => setFilters({ ...initialFilters, radius: 300 })}
          >
            Reset filters
          </button>
        </div>
      )}
    </div>
  );
}
