"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/image";
import type { ChatListData } from "@/lib/types";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "now";
  if (mins < 60) return `${mins}m`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h`;
  return `${Math.round(hours / 24)}d`;
}

export default function ChatListPage() {
  const [data, setData] = useState<ChatListData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const result = await apiFetch<ChatListData>("/api/chat");
        if (alive) setData(result);
      } catch (err) {
        if (alive) setError(err instanceof Error ? err.message : "Could not load chats.");
      }
    }
    void load();
    const timer = setInterval(load, 15000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, []);

  return (
    <div>
      <div className="flex items-end justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-cream/40">Private</p>
          <h1 className="display mt-1 text-3xl sm:text-4xl">Chats</h1>
          <p className="mt-1 text-[12px] text-cream/50">
            Only mutual matches can message you. Photos in chat respect both members&apos; privacy
            toggles.
          </p>
        </div>
        {data && data.totalUnread > 0 && (
          <span className="badge-danger">{data.totalUnread} unread</span>
        )}
      </div>

      {error && (
        <p className="mt-4 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-xs text-rose">
          {error}
        </p>
      )}

      <div className="mt-5 space-y-2">
        {(data?.threads ?? []).map((thread) => (
          <Link
            key={thread.userId}
            href={`/app/chat/${thread.userId}`}
            className="card flex items-center gap-3 p-3 transition hover:border-white/20"
          >
            <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-2xl bg-ink-soft">
              {thread.photoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={thread.photoUrl} alt={thread.fullName} className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-lg">🔒</div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-[14px] font-semibold">
                  {thread.fullName}
                  {thread.identityVerified && <span className="ml-1 text-mint">✓</span>}
                </p>
                <span className="shrink-0 text-[10px] text-cream/35">
                  {thread.lastMessage ? timeAgo(thread.lastMessage.at) : "new match"}
                </span>
              </div>
              <p className="truncate text-[11.5px] text-cream/50">
                {thread.lastMessage
                  ? `${thread.lastMessage.fromMe ? "You: " : ""}${thread.lastMessage.body || "📷 Photo"}`
                  : "You matched — say hello 👋"}
              </p>
              <p className="truncate text-[10px] text-cream/30">
                {thread.area || thread.city}
              </p>
            </div>
            {thread.unread > 0 && (
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-rose px-1.5 text-[10px] font-bold text-white">
                {thread.unread}
              </span>
            )}
          </Link>
        ))}
      </div>

      {data && data.threads.length === 0 && (
        <div className="card mt-4 p-10 text-center">
          <p className="text-3xl">💬</p>
          <h3 className="display mt-3 text-xl">No conversations yet</h3>
          <p className="mx-auto mt-2 max-w-sm text-[12px] text-cream/50">
            Chat is unlocked by a mutual like. Like someone nearby — if they like you back, the
            conversation appears here.
          </p>
          <Link href="/app" className="btn-primary btn-sm mt-4 inline-flex">Find people nearby</Link>
        </div>
      )}

      <div className="card mt-4 flex items-start gap-3 p-4 text-[11px] leading-relaxed text-cream/45">
        <span className="text-base">🔐</span>
        <p>
          Never share OTPs, bank details or money requests. Milap never asks for payment inside
          chat — membership is paid only to the official admin UPI ID. Report any member who asks
          for money.
        </p>
      </div>
    </div>
  );
}
