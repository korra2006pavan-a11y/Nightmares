"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { apiFetch, fileToDataUrl } from "@/lib/image";
import type { ChatMessage, ThreadData } from "@/lib/types";

export default function ChatThreadPage() {
  const params = useParams<{ userId: string }>();
  const userId = params?.userId;
  const [data, setData] = useState<ThreadData | null>(null);
  const [error, setError] = useState("");
  const [text, setText] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const result = await apiFetch<ThreadData>(`/api/chat/${userId}`);
      setData(result);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not open this chat.");
    }
  }, [userId]);

  useEffect(() => {
    void load();
    const timer = setInterval(load, 6000);
    return () => clearInterval(timer);
  }, [load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [data?.messages.length]);

  async function send() {
    if (!text.trim() && !image) return;
    setSending(true);
    setError("");
    try {
      await apiFetch<{ message: ChatMessage }>(`/api/chat/${userId}`, {
        method: "POST",
        body: JSON.stringify({ body: text, image }),
      });
      setText("");
      setImage(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Message not sent.");
    } finally {
      setSending(false);
    }
  }

  if (error && !data) {
    return (
      <div className="card p-8 text-center">
        <p className="text-3xl">🔒</p>
        <h1 className="display mt-2 text-2xl">{error}</h1>
        <Link href="/app/chat" className="btn-ghost btn-sm mt-4 inline-flex">Back to chats</Link>
      </div>
    );
  }

  if (!data) return <p className="py-20 text-center text-sm text-cream/40">Opening chat…</p>;

  const partner = data.partner;

  return (
    <div className="mx-auto max-w-2xl">
      <div className="card sticky top-16 z-20 flex items-center gap-3 p-3 backdrop-blur-xl">
        <Link href="/app/chat" className="text-cream/45 hover:text-cream">←</Link>
        <div className="h-10 w-10 shrink-0 overflow-hidden rounded-xl bg-ink-soft">
          {partner.photoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={partner.photoUrl} alt={partner.fullName} className="h-full w-full object-cover" />
          ) : (
            <div className="grid h-full place-items-center">🔒</div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-semibold">
            {partner.fullName}
            {partner.identityVerified && <span className="ml-1 text-mint">✓</span>}
          </p>
          <p className="truncate text-[10px] text-cream/40">
            {partner.area || partner.city} · matched
          </p>
        </div>
        {partner.phone ? (
          <a href={`tel:+91${partner.phone}`} className="btn-mint btn-sm">📞 Call</a>
        ) : (
          <span className="badge-muted">number private</span>
        )}
      </div>

      {!data.isMember && (
        <div className="mt-3 rounded-2xl border border-rose/30 bg-rose/[0.08] p-3 text-[11.5px] text-cream/70">
          Membership required to send messages.{" "}
          <Link href="/app/membership" className="underline">Activate for ₹99 →</Link>
        </div>
      )}

      <div className="mt-3 space-y-2.5">
        {data.messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.fromMe ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${
                message.fromMe
                  ? "rounded-br-sm bg-gradient-to-br from-rose to-rose-deep text-white"
                  : "rounded-bl-sm border border-white/10 bg-white/[0.06] text-cream/85"
              }`}
            >
              {message.body && <p className="whitespace-pre-wrap">{message.body}</p>}
              {message.imageUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={message.imageUrl}
                  alt="Shared photo"
                  className="mt-1.5 max-h-64 w-full rounded-xl object-cover"
                />
              )}
              {message.imageBlocked && (
                <p className="mt-1.5 rounded-lg border border-gold/30 bg-gold/10 px-2 py-1 text-[10px] text-gold">
                  🔒 Photo hidden — you turned off photo sharing in chat.
                </p>
              )}
              <p className={`mt-1 text-[9px] ${message.fromMe ? "text-white/60" : "text-cream/30"}`}>
                {new Date(message.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                {message.fromMe && (message.read ? " · read" : " · sent")}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {data.messages.length === 0 && (
        <p className="py-10 text-center text-[12px] text-cream/40">
          You matched. Say something better than &quot;hi&quot; 😄
        </p>
      )}

      {error && (
        <p className="mt-2 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-[11px] text-rose">
          {error}
        </p>
      )}

      {image && (
        <div className="mt-3 flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 p-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt="Attachment preview" className="h-14 w-14 rounded-xl object-cover" />
          <p className="flex-1 text-[11px] text-cream/50">Photo ready to send</p>
          <button onClick={() => setImage(null)} className="text-[11px] text-rose">Remove</button>
        </div>
      )}

      <div className="sticky bottom-16 mt-3 md:bottom-3">
        <div className="card flex items-end gap-2 p-2">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/12 bg-white/5 text-base hover:bg-white/10"
            title={
              data.viewerAllowChatPhotos
                ? "Attach a photo"
                : "Enable photo sharing in Settings first"
            }
          >
            📷
          </button>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            rows={1}
            placeholder={`Message ${partner.fullName.split(" ")[0]}…`}
            className="max-h-28 min-h-10 flex-1 resize-none bg-transparent px-2 py-2.5 text-[13px] outline-none placeholder:text-cream/30"
          />
          <button
            onClick={send}
            disabled={sending || (!text.trim() && !image)}
            className="btn-primary btn-sm h-10 shrink-0"
          >
            {sending ? "…" : "Send"}
          </button>
        </div>
        <p className="mt-1.5 text-center text-[10px] text-cream/25">
          {partner.allowChatPhotos
            ? "You can exchange photos · never share OTPs or bank details"
            : `${partner.fullName.split(" ")[0]} has disabled photo sharing`}
        </p>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          try {
            setImage(await fileToDataUrl(file, 1000));
          } catch (err) {
            setError(err instanceof Error ? err.message : "Could not attach that image.");
          }
        }}
      />
    </div>
  );
}
