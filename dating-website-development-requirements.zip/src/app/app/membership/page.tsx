"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import QRCode from "qrcode";
import { ImagePicker } from "@/components/ImagePicker";
import { apiFetch } from "@/lib/image";
import type { PaymentData } from "@/lib/types";

const RULES = [
  "12-digit numeric UPI reference (UTR / RRN)",
  "Reference must be unused across all of Milap",
  "Payment screenshot is mandatory",
  "Amount must be exactly ₹99",
  "Repeating or high-velocity UTRs go to manual review",
];

export default function MembershipPage() {
  const router = useRouter();
  const [data, setData] = useState<PaymentData | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ kind: "ok" | "warn" | "error"; text: string } | null>(null);

  const load = useCallback(async () => {
    try {
      const payment = await apiFetch<PaymentData>("/api/payment");
      setData(payment);
      const qrData = await QRCode.toDataURL(payment.upiLink, {
        width: 420,
        margin: 1,
        color: { dark: "#110a14", light: "#fbf3ea" },
      });
      setQr(qrData);
    } catch (err) {
      setResult({
        kind: "error",
        text: err instanceof Error ? err.message : "Could not load membership details.",
      });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function submit() {
    setBusy(true);
    setResult(null);
    try {
      const response = await apiFetch<{ verdict: string; message: string }>("/api/payment", {
        method: "POST",
        body: JSON.stringify({ utr, screenshot }),
      });
      setResult({
        kind: response.verdict === "verified" ? "ok" : "warn",
        text: response.message,
      });
      setUtr("");
      setScreenshot(null);
      await load();
      router.refresh();
    } catch (err) {
      setResult({
        kind: "error",
        text: err instanceof Error ? err.message : "Payment verification failed.",
      });
    } finally {
      setBusy(false);
    }
  }

  function demoProof() {
    const generated = Array.from({ length: 12 }, () => Math.floor(Math.random() * 10)).join("");
    setUtr(generated);
    const canvas = document.createElement("canvas");
    canvas.width = 460;
    canvas.height = 720;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#16a34a";
      ctx.beginPath();
      ctx.arc(230, 150, 54, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 54px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("✓", 230, 170);
      ctx.fillStyle = "#111827";
      ctx.font = "bold 26px sans-serif";
      ctx.fillText("Payment Successful", 230, 250);
      ctx.font = "44px sans-serif";
      ctx.fillText("₹99.00", 230, 320);
      ctx.font = "16px sans-serif";
      ctx.fillStyle = "#4b5563";
      ctx.fillText("Milap Membership", 230, 360);
      ctx.fillText("Paid to", 230, 420);
      ctx.fillStyle = "#111827";
      ctx.font = "bold 18px sans-serif";
      ctx.fillText("korra.59@ptaxis", 230, 450);
      ctx.fillStyle = "#6b7280";
      ctx.font = "15px sans-serif";
      ctx.fillText(`UTR: ${generated}`, 230, 520);
      ctx.fillText(new Date().toLocaleString(), 230, 550);
      ctx.fillStyle = "#9ca3af";
      ctx.font = "12px sans-serif";
      ctx.fillText("Sample receipt for checker demo", 230, 640);
    }
    setScreenshot(canvas.toDataURL("image/jpeg", 0.85));
    setResult({
      kind: "warn",
      text: "Sample UTR + receipt generated. Submit to see the automatic UTR check. A real payment needs a genuine reference.",
    });
  }

  const isMember = data?.requirements.isMember ?? false;
  const missing = data
    ? [
        !data.requirements.emailVerified && "Email OTP",
        !data.requirements.phoneVerified && "Mobile OTP",
        !data.requirements.hasPhoto && "Profile photo",
        !data.requirements.hasSelfie && "Verification selfie",
      ].filter(Boolean)
    : [];

  return (
    <div>
      <p className="text-[11px] uppercase tracking-[0.2em] text-cream/40">Membership</p>
      <h1 className="display mt-1 text-3xl sm:text-4xl">₹99 monthly plan</h1>
      <p className="mt-1 max-w-2xl text-[12px] text-cream/50">
        Pay by UPI, upload the success screenshot with the 12-digit UTR, and the checker activates
        30 days of access automatically. No auto-debit, no hidden coins.
      </p>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">1 · Pay via UPI</h2>
            <span className={isMember ? "badge-verified" : "badge-warn"}>
              {isMember ? `active · ${data?.membership.daysLeft}d left` : data?.membership.status ?? "pending"}
            </span>
          </div>

          <div className="mt-4 flex flex-col items-center gap-3 rounded-2xl border border-gold/25 bg-gold/[0.06] p-4 sm:flex-row">
            {qr ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={qr} alt="UPI QR code" className="h-32 w-32 rounded-xl border border-white/10" />
            ) : (
              <div className="grid h-32 w-32 place-items-center rounded-xl border border-white/10 text-[10px] text-cream/30">
                generating QR…
              </div>
            )}
            <div className="min-w-0 flex-1 text-center sm:text-left">
              <p className="text-[10px] uppercase tracking-widest text-gold/70">Admin UPI ID</p>
              <p className="mt-1 break-all font-mono text-[15px] text-gold">
                {data?.plan.upiId ?? "korra.59@ptaxis"}
              </p>
              <p className="text-[11px] text-cream/45">Payee: {data?.plan.upiName ?? "Milap Membership"}</p>
              <p className="mt-2 text-[26px] font-semibold leading-none">
                ₹{data?.plan.amount ?? 99}
                <span className="ml-1 text-[11px] font-normal text-cream/40">/ 30 days</span>
              </p>
              <p className="mt-1 text-[10px] text-cream/40">Note: {data?.plan.note ?? "MILAP-USER"}</p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              className="btn-ghost btn-sm"
              onClick={async () => {
                await navigator.clipboard.writeText(data?.plan.upiId ?? "korra.59@ptaxis");
                setResult({ kind: "ok", text: "UPI ID copied. Pay ₹99 in your UPI app." });
              }}
            >
              Copy UPI ID
            </button>
            {data && (
              <a href={data.upiLink} className="btn-primary btn-sm">
                Open UPI app
              </a>
            )}
            <span className="chip text-[10px]">GPay · PhonePe · Paytm · BHIM</span>
          </div>

          <div className="mt-4 space-y-1.5">
            {[
              ["Email OTP", data?.requirements.emailVerified],
              ["Mobile OTP", data?.requirements.phoneVerified],
              ["Profile photo", data?.requirements.hasPhoto],
              ["Verification selfie", data?.requirements.hasSelfie],
            ].map(([label, done]) => (
              <div key={String(label)} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-3 py-1.5 text-[11.5px]">
                <span className="text-cream/55">{label}</span>
                <span className={done ? "text-mint" : "text-rose"}>{done ? "✓ done" : "pending"}</span>
              </div>
            ))}
          </div>
          {missing.length > 0 && (
            <p className="mt-3 text-[11px] text-gold">
              Finish {missing.join(", ")} before submitting payment proof.{" "}
              <Link href="/verify" className="underline">Complete verification →</Link>
            </p>
          )}
        </div>

        <div className="card p-5">
          <h2 className="text-sm font-semibold">2 · Upload proof &amp; UTR</h2>
          <p className="mt-1 text-[11px] text-cream/45">
            We check the reference against every previous payment on Milap.
          </p>

          <div className="mt-4">
            <ImagePicker
              label="Payment screenshot"
              hint="Success screen from your UPI app showing the amount, payee and UTR."
              value={screenshot}
              onChange={setScreenshot}
            />
          </div>

          <div className="mt-4">
            <label className="label">UTR / RRN (12 digits)</label>
            <input
              className="input font-mono tracking-[0.18em]"
              inputMode="numeric"
              maxLength={12}
              placeholder="402219876531"
              value={utr}
              onChange={(e) => setUtr(e.target.value.replace(/\D/g, "").slice(0, 12))}
            />
            <p className="mt-1 text-[10px] text-cream/35">
              Find it in your UPI app under transaction details. Never share OTPs or PINs.
            </p>
          </div>

          <button
            onClick={submit}
            disabled={busy || isMember || missing.length > 0 || utr.length !== 12 || !screenshot}
            className="btn-primary mt-4 w-full"
          >
            {busy ? "Checking UTR…" : isMember ? "Membership already active" : "Verify UTR & activate"}
          </button>

          <button onClick={demoProof} className="btn-ghost btn-sm mt-2 w-full">
            Generate sample UTR + receipt (test mode)
          </button>

          {result && (
            <p
              className={`mt-3 rounded-xl border px-3 py-2 text-[11.5px] ${
                result.kind === "ok"
                  ? "border-mint/30 bg-mint/10 text-mint"
                  : result.kind === "warn"
                    ? "border-gold/30 bg-gold/10 text-gold"
                    : "border-rose/30 bg-rose/10 text-rose"
              }`}
            >
              {result.text}
            </p>
          )}

          <div className="mt-4 rounded-xl border border-white/10 bg-black/25 p-3">
            <p className="text-[10px] uppercase tracking-widest text-cream/35">UTR checker rules</p>
            <ul className="mt-1.5 space-y-1 text-[11px] text-cream/50">
              {RULES.map((rule) => (
                <li key={rule} className="flex gap-2">
                  <span className="text-rose">•</span> {rule}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {data && data.payments.length > 0 && (
        <div className="card mt-4 p-5">
          <h2 className="text-sm font-semibold">Payment history</h2>
          <div className="mt-3 space-y-2">
            {data.payments.map((payment) => (
              <div key={payment.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-white/10 bg-black/20 p-3">
                <span className="font-mono text-[12px] text-cream/80">UTR {payment.utr}</span>
                <span
                  className={
                    payment.status === "verified"
                      ? "badge-verified"
                      : payment.status === "rejected"
                        ? "badge-danger"
                        : "badge-warn"
                  }
                >
                  {payment.status.replace("_", " ")}
                </span>
                <span className="text-[11px] text-cream/40">₹{payment.amount}</span>
                <span className="text-[11px] text-cream/35">
                  {new Date(payment.createdAt).toLocaleString()}
                </span>
                {payment.screenshotUrl && (
                  <a href={payment.screenshotUrl} target="_blank" rel="noreferrer" className="text-[11px] text-rose hover:underline">
                    View screenshot
                  </a>
                )}
                {payment.checkerNote && (
                  <p className="w-full text-[11px] text-cream/40">{payment.checkerNote}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
