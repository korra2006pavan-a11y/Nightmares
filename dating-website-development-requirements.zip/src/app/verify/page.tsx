"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ImagePicker } from "@/components/ImagePicker";
import { ADMIN_UPI_ID, PLAN, SITE } from "@/lib/config";
import { apiFetch } from "@/lib/image";
import type { Me } from "@/lib/types";

type Channel = "email" | "phone";

export default function VerifyPage() {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [codes, setCodes] = useState<Record<string, string>>({});
  const [dev, setDev] = useState<Record<string, string>>({});
  const [notices, setNotices] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [busy, setBusy] = useState<Channel | "selfie" | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await apiFetch<{ user: Me | null }>("/api/auth/me");
      if (!data.user) {
        router.replace("/login");
        return;
      }
      setMe(data.user);
    } catch {
      router.replace("/login");
    }
  }, [router]);

  useEffect(() => {
    void load();
    const stored = sessionStorage.getItem("milap_demo_codes");
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as Record<string, string>;
        setCodes(parsed);
        setDev(parsed);
        sessionStorage.removeItem("milap_demo_codes");
      } catch {
        /* ignore */
      }
    }
  }, [load]);

  async function sendCode(channel: Channel) {
    setBusy(channel);
    setError("");
    try {
      const data = await apiFetch<{ devCode: string; destination: string; message: string }>(
        "/api/auth/otp",
        { method: "POST", body: JSON.stringify({ channel }) },
      );
      setCodes((prev) => ({ ...prev, [channel]: data.devCode }));
      setDev((prev) => ({ ...prev, [channel]: data.devCode }));
      setNotices((prev) => ({
        ...prev,
        [channel]: `Sent to ${data.destination}. ${data.message}`,
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not send OTP.");
    } finally {
      setBusy(null);
    }
  }

  async function verify(channel: Channel) {
    setBusy(channel);
    setError("");
    try {
      const data = await apiFetch<{ user: Me; message: string }>("/api/auth/otp", {
        method: "PUT",
        body: JSON.stringify({ channel, code: codes[channel] ?? "" }),
      });
      setMe(data.user);
      setNotices((prev) => ({ ...prev, [channel]: data.message }));
      setDev((prev) => ({ ...prev, [channel]: "" }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not verify OTP.");
    } finally {
      setBusy(null);
    }
  }

  async function saveSelfie() {
    if (!selfie) return;
    setBusy("selfie");
    setError("");
    try {
      const data = await apiFetch<{ user: Me }>("/api/profile", {
        method: "PATCH",
        body: JSON.stringify({ selfie }),
      });
      setMe(data.user);
      setSelfie(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the selfie.");
    } finally {
      setBusy(null);
    }
  }

  if (!me) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-cream/50">Loading…</div>
    );
  }

  const emailDone = me.emailVerified;
  const phoneDone = me.phoneVerified;
  const allDone = emailDone && phoneDone && me.hasSelfie;

  return (
    <main className="mx-auto max-w-3xl px-5 py-8">
      <div className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-rose to-rose-deep">
            ❤
          </span>
          <span className="display text-xl">{SITE.name}</span>
        </Link>
        <Link href="/login" className="text-xs text-cream/50 hover:text-cream">Sign out</Link>
      </div>

      <div className="mt-10">
        <span className="chip border-gold/30 bg-gold/10 text-gold">Step 2 of 3 · verification</span>
        <h1 className="display mt-4 text-4xl">Prove you&apos;re a real person</h1>
        <p className="mt-2 max-w-xl text-sm text-cream/60">
          Hi {me.fullName.split(" ")[0]} — confirm your email and mobile with OTP, then add a
          verification selfie. Only after that can you pay the ₹{PLAN.amount} membership and unlock
          photos, contact sharing and chat.
        </p>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          ["Email", emailDone, me.email],
          ["Mobile", phoneDone, `+91 ${me.phone}`],
          ["Selfie", me.hasSelfie, "admin-only check"],
        ].map(([label, done, detail]) => (
          <div key={String(label)} className="card p-4">
            <div className="flex items-center justify-between">
              <p className="text-[11px] uppercase tracking-widest text-cream/40">{label}</p>
              <span className={done ? "badge-verified" : "badge-warn"}>
                {done ? "verified" : "pending"}
              </span>
            </div>
            <p className="mt-2 truncate text-[12px] text-cream/60">{detail}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        {(["email", "phone"] as Channel[]).map((channel) => {
          const done = channel === "email" ? emailDone : phoneDone;
          return (
            <div key={channel} className="card p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold">
                  {channel === "email" ? "Email OTP" : "Mobile OTP"}
                </h2>
                {done && <span className="badge-verified">verified</span>}
              </div>
              <p className="mt-1 truncate text-[11px] text-cream/45">
                {channel === "email" ? me.email : `+91 ${me.phone}`}
              </p>
              {done ? (
                <p className="mt-4 rounded-xl border border-mint/20 bg-mint/5 px-3 py-2 text-[11px] text-mint">
                  Verified. Nothing more to do here.
                </p>
              ) : (
                <>
                  <div className="mt-4 flex gap-2">
                    <input
                      className="input tracking-[0.4em]"
                      inputMode="numeric"
                      maxLength={6}
                      placeholder="000000"
                      value={codes[channel] ?? ""}
                      onChange={(e) =>
                        setCodes((prev) => ({
                          ...prev,
                          [channel]: e.target.value.replace(/\D/g, "").slice(0, 6),
                        }))
                      }
                    />
                    <button
                      type="button"
                      className="btn-primary btn-sm shrink-0"
                      onClick={() => verify(channel)}
                      disabled={busy !== null}
                    >
                      {busy === channel ? "…" : "Verify"}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => sendCode(channel)}
                    disabled={busy !== null}
                    className="mt-2 text-[11px] text-rose hover:underline"
                  >
                    {dev[channel] ? "Resend code" : "Send OTP"}
                  </button>
                  {notices[channel] && (
                    <p className="mt-2 text-[11px] text-cream/45">{notices[channel]}</p>
                  )}
                  {dev[channel] && (
                    <p className="mt-1 rounded-lg border border-gold/25 bg-gold/10 px-2 py-1.5 text-[11px] text-gold">
                      Demo OTP: <strong className="tracking-[0.2em]">{dev[channel]}</strong>
                    </p>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>

      <div className="card mt-4 p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold">Verification selfie</h2>
            <p className="mt-1 max-w-md text-[11px] leading-relaxed text-cream/45">
              Seen only by Trust &amp; Safety — never shown to members. A clear face photo helps us
              remove impersonators quickly.
            </p>
          </div>
          {me.hasSelfie && <span className="badge-verified">on file</span>}
        </div>
        <div className="mt-4">
          <ImagePicker
            label={me.hasSelfie ? "Replace selfie" : "Upload selfie"}
            value={selfie}
            onChange={setSelfie}
            shape="circle"
            hint="Front camera or well-lit mirror photo works fine."
          />
        </div>
        {selfie && (
          <button
            type="button"
            className="btn-mint btn-sm mt-3"
            onClick={saveSelfie}
            disabled={busy !== null}
          >
            {busy === "selfie" ? "Saving…" : "Save selfie"}
          </button>
        )}
      </div>

      {error && (
        <p className="mt-4 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-xs text-rose">
          {error}
        </p>
      )}

      <div className="card mt-4 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold">Next: activate membership</h2>
            <p className="mt-1 text-[11px] text-cream/45">
              Pay ₹{PLAN.amount} to {ADMIN_UPI_ID}, then upload the screenshot with your UTR.
            </p>
          </div>
          <div className="flex gap-2">
            <Link href="/app" className="btn-ghost btn-sm">Skip for now</Link>
            <Link href="/app/membership" className="btn-primary btn-sm">
              Continue to payment →
            </Link>
          </div>
        </div>
        {!allDone && (
          <p className="mt-3 text-[11px] text-gold/80">
            Finish email, mobile and selfie verification to submit your payment.
          </p>
        )}
      </div>
    </main>
  );
}
