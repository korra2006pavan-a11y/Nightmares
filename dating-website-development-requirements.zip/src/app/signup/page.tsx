"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { ImagePicker } from "@/components/ImagePicker";
import { ADMIN_UPI_ID, PLAN, SITE } from "@/lib/config";
import { apiFetch, getBrowserLocation } from "@/lib/image";
import { CITIES } from "@/lib/geo";
import type { Me } from "@/lib/types";

type Step = 0 | 1 | 2;

const LOOKING_FOR = ["Long-term", "Dating", "Hookup", "Friendship", "Marriage"];
const YEARS = Array.from({ length: 60 }, (_, i) => new Date().getFullYear() - 18 - i);

export default function SignupPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [locationNote, setLocationNote] = useState("");

  const [form, setForm] = useState({
    loginId: "",
    email: "",
    phone: "",
    password: "",
    confirm: "",
    fullName: "",
    gender: "female",
    interestedIn: "male",
    birthYear: 1996,
    city: "Hyderabad",
    area: "",
    bio: "",
    lookingFor: "Long-term",
    lat: 17.385 as number | null,
    lng: 78.4867 as number | null,
    photo: null as string | null,
    selfie: null as string | null,
    consent: false,
  });

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const progress = useMemo(() => (step + 1) * 33.4, [step]);

  function next() {
    setError("");
    if (step === 0) {
      if (!/^[a-z0-9_]{3,20}$/.test(form.loginId)) {
        setError("Login ID: 3–20 lowercase letters, numbers or underscore.");
        return;
      }
      if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(form.email)) {
        setError("Enter a valid email address.");
        return;
      }
      if (!/^\d{10}$/.test(form.phone)) {
        setError("Enter your 10-digit mobile number.");
        return;
      }
      if (form.password.length < 8) {
        setError("Password must be at least 8 characters.");
        return;
      }
      if (form.password !== form.confirm) {
        setError("Passwords do not match.");
        return;
      }
    }
    if (step === 1) {
      if (form.fullName.trim().length < 2) {
        setError("Tell us your name.");
        return;
      }
      if (!form.city) {
        setError("Select your city.");
        return;
      }
      if (form.bio.trim().length < 20) {
        setError("Write at least 20 characters about yourself — it helps us spot fake profiles.");
        return;
      }
    }
    setStep((prev) => (prev + 1) as Step);
  }

  async function submit() {
    setError("");
    if (!form.photo) {
      setError("A profile photo is required — members must be able to see who they are meeting.");
      return;
    }
    if (!form.selfie) {
      setError("Upload a verification selfie so our team can match it with your photo.");
      return;
    }
    if (!form.consent) {
      setError("Confirm that you are 18+ and agree to the safety rules.");
      return;
    }
    setBusy(true);
    try {
      const data = await apiFetch<{ user: Me; demoCodes: { email: string; phone: string } }>(
        "/api/auth/signup",
        {
          method: "POST",
          body: JSON.stringify({
            ...form,
            birthYear: Number(form.birthYear),
          }),
        },
      );
      sessionStorage.setItem(
        "milap_demo_codes",
        JSON.stringify(data.demoCodes ?? {}),
      );
      router.push("/verify");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create your account.");
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-5xl px-5 py-8">
      <div className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-rose to-rose-deep">
            ❤
          </span>
          <span className="display text-xl">{SITE.name}</span>
        </Link>
        <Link href="/login" className="text-xs text-cream/50 hover:text-cream">
          Already a member? Sign in
        </Link>
      </div>

      <div className="mx-auto mt-10 max-w-2xl">
        <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-rose to-gold transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-3 flex justify-between text-[10px] uppercase tracking-widest text-cream/40">
          <span className={step === 0 ? "text-rose" : ""}>1 · Account</span>
          <span className={step === 1 ? "text-rose" : ""}>2 · Profile</span>
          <span className={step === 2 ? "text-rose" : ""}>3 · Verification</span>
        </div>

        <div className="card mt-6 p-6 sm:p-8">
          {step === 0 && (
            <div>
              <h1 className="display text-3xl">Create your login</h1>
              <p className="mt-1 text-xs text-cream/45">
                These credentials are what you use to sign in — email and mobile are OTP verified
                in the next step.
              </p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label">Login ID</label>
                  <input
                    className="input"
                    value={form.loginId}
                    onChange={(e) =>
                      set("loginId", e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))
                    }
                    placeholder="e.g. ananya_26"
                    autoComplete="username"
                  />
                </div>
                <div>
                  <label className="label">Email address</label>
                  <input
                    className="input"
                    type="email"
                    value={form.email}
                    onChange={(e) => {
                      const email = e.target.value;
                      set("email", email);
                      if (!form.loginId) {
                        const guess = email.split("@")[0]?.toLowerCase().replace(/[^a-z0-9_]/g, "");
                        if (guess && guess.length >= 3) set("loginId", guess.slice(0, 20));
                      }
                    }}
                    placeholder="you@example.com"
                    autoComplete="email"
                  />
                </div>
                <div>
                  <label className="label">Mobile number</label>
                  <div className="flex items-center gap-2">
                    <span className="rounded-xl border border-white/12 bg-black/30 px-3 py-3 text-xs text-cream/50">+91</span>
                    <input
                      className="input"
                      inputMode="numeric"
                      value={form.phone}
                      onChange={(e) => set("phone", e.target.value.replace(/\D/g, "").slice(0, 10))}
                      placeholder="98765 43210"
                      autoComplete="tel"
                    />
                  </div>
                </div>
                <div>
                  <label className="label">Password</label>
                  <input
                    className="input"
                    type="password"
                    value={form.password}
                    onChange={(e) => set("password", e.target.value)}
                    placeholder="At least 8 characters"
                    autoComplete="new-password"
                  />
                </div>
                <div>
                  <label className="label">Confirm password</label>
                  <input
                    className="input"
                    type="password"
                    value={form.confirm}
                    onChange={(e) => set("confirm", e.target.value)}
                    placeholder="Repeat password"
                    autoComplete="new-password"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 1 && (
            <div>
              <h1 className="display text-3xl">About you</h1>
              <p className="mt-1 text-xs text-cream/45">
                Be honest — profiles with a full bio and real details pass verification faster.
              </p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="label">Full name</label>
                  <input
                    className="input"
                    value={form.fullName}
                    onChange={(e) => set("fullName", e.target.value)}
                    placeholder="Ananya Rao"
                  />
                </div>
                <div>
                  <label className="label">I am</label>
                  <select
                    className="input"
                    value={form.gender}
                    onChange={(e) => set("gender", e.target.value)}
                  >
                    <option value="female">Woman</option>
                    <option value="male">Man</option>
                    <option value="other">Other / prefer to self-describe</option>
                  </select>
                </div>
                <div>
                  <label className="label">Interested in</label>
                  <select
                    className="input"
                    value={form.interestedIn}
                    onChange={(e) => set("interestedIn", e.target.value)}
                  >
                    <option value="male">Men</option>
                    <option value="female">Women</option>
                    <option value="any">Anyone</option>
                  </select>
                </div>
                <div>
                  <label className="label">Birth year (18+)</label>
                  <select
                    className="input"
                    value={form.birthYear}
                    onChange={(e) => set("birthYear", Number(e.target.value))}
                  >
                    {YEARS.map((year) => (
                      <option key={year} value={year}>
                        {year} · {new Date().getFullYear() - year} yrs
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Looking for</label>
                  <select
                    className="input"
                    value={form.lookingFor}
                    onChange={(e) => set("lookingFor", e.target.value)}
                  >
                    {LOOKING_FOR.map((item) => (
                      <option key={item} value={item}>{item}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">City</label>
                  <select
                    className="input"
                    value={form.city}
                    onChange={(e) => {
                      const city = CITIES.find((c) => c.name === e.target.value);
                      setForm((prev) => ({
                        ...prev,
                        city: e.target.value,
                        lat: city?.lat ?? prev.lat,
                        lng: city?.lng ?? prev.lng,
                      }));
                    }}
                  >
                    {CITIES.map((city) => (
                      <option key={city.name} value={city.name}>
                        {city.name}, {city.state}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Area / neighbourhood</label>
                  <input
                    className="input"
                    value={form.area}
                    onChange={(e) => set("area", e.target.value)}
                    placeholder="Jubilee Hills"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="label">Short intro (min 20 characters)</label>
                  <textarea
                    className="input min-h-24 resize-none"
                    maxLength={600}
                    value={form.bio}
                    onChange={(e) => set("bio", e.target.value)}
                    placeholder="What do you do, what do you enjoy, and what are you actually looking for?"
                  />
                  <p className="mt-1 text-right text-[10px] text-cream/30">{form.bio.length}/600</p>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h1 className="display text-3xl">Verify it&apos;s really you</h1>
              <p className="mt-1 text-xs text-cream/45">
                Your photo is shown to verified members. The selfie is used only by Trust &amp;
                Safety and is never shown to anyone else.
              </p>
              <div className="mt-6 grid gap-6 sm:grid-cols-2">
                <ImagePicker
                  label="Profile photo"
                  hint="Clear face, good light, no group photos or filters."
                  value={form.photo}
                  onChange={(value) => set("photo", value)}
                  shape="square"
                  required
                />
                <ImagePicker
                  label="Verification selfie"
                  hint="Hold your phone at eye level. Admin-only, never public."
                  value={form.selfie}
                  onChange={(value) => set("selfie", value)}
                  shape="circle"
                  required
                />
              </div>

              <div className="mt-6 rounded-2xl border border-white/10 bg-black/25 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-[13px] font-medium">Approximate location</p>
                    <p className="text-[11px] text-cream/45">
                      {form.lat != null && form.lng != null
                        ? `${form.lat.toFixed(3)}, ${form.lng.toFixed(3)} · ${form.city}`
                        : "Pick a city above"}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="btn-ghost btn-sm"
                    onClick={async () => {
                      try {
                        const coords = await getBrowserLocation();
                        setForm((prev) => ({ ...prev, ...coords }));
                        setLocationNote("Location captured — nearest-first matching is on.");
                      } catch (err) {
                        setLocationNote(
                          err instanceof Error ? err.message : "Could not get your location.",
                        );
                      }
                    }}
                  >
                    📍 Use my location
                  </button>
                </div>
                {locationNote && (
                  <p className="mt-2 text-[11px] text-mint/80">{locationNote}</p>
                )}
              </div>

              <label className="mt-5 flex cursor-pointer items-start gap-3 text-[12px] text-cream/60">
                <input
                  type="checkbox"
                  checked={form.consent}
                  onChange={(e) => set("consent", e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-rose"
                />
                <span>
                  I am 18+, the photos are mine, and I agree not to send money to anyone I meet
                  here. Membership is ₹{PLAN.amount}/month paid to {ADMIN_UPI_ID}.
                </span>
              </label>
            </div>
          )}

          {error && (
            <p className="mt-5 rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-xs text-rose">
              {error}
            </p>
          )}

          <div className="mt-7 flex items-center justify-between gap-3">
            <button
              type="button"
              className="btn-ghost btn-sm"
              onClick={() => (step === 0 ? router.push("/") : setStep((step - 1) as Step))}
            >
              ← Back
            </button>
            {step < 2 ? (
              <button type="button" className="btn-primary" onClick={next}>
                Continue
              </button>
            ) : (
              <button type="button" className="btn-primary" onClick={submit} disabled={busy}>
                {busy ? "Creating…" : "Create account & verify OTP"}
              </button>
            )}
          </div>
        </div>

        <p className="mt-4 text-center text-[11px] text-cream/30">
          Your data stays inside Milap. Contact details are never sold or public.
        </p>
      </div>
    </main>
  );
}
