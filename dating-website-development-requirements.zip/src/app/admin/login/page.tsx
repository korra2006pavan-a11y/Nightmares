"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ADMIN_UPI_ID, DEMO_ADMIN } from "@/lib/config";
import { apiFetch } from "@/lib/image";
import type { Me } from "@/lib/types";

export default function AdminLoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await apiFetch<{ user: Me; redirect: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ identifier, password }),
      });
      if (data.user.role !== "admin") {
        setError("This account is not an admin. Use the member login instead.");
        setBusy(false);
        return;
      }
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid min-h-screen max-w-md place-items-center px-5 py-10">
      <div className="w-full">
        <Link href="/" className="mb-6 flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-rose to-rose-deep">
            ❤
          </span>
          <span className="display text-xl">Milap</span>
          <span className="badge-warn">admin</span>
        </Link>
        <div className="card p-6">
          <h1 className="display text-2xl">Trust &amp; Safety console</h1>
          <p className="mt-1 text-[11px] text-cream/45">
            Payment verification, fake-profile removal and member reports. Payments settle to{" "}
            <span className="text-gold">{ADMIN_UPI_ID}</span>.
          </p>
          <form onSubmit={submit} className="mt-5 space-y-3">
            <div>
              <label className="label">Admin login ID or email</label>
              <input
                className="input"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="label">Password</label>
              <input
                type="password"
                className="input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && (
              <p className="rounded-xl border border-rose/30 bg-rose/10 px-3 py-2 text-[11px] text-rose">
                {error}
              </p>
            )}
            <button className="btn-primary w-full" disabled={busy}>
              {busy ? "Checking…" : "Enter console"}
            </button>
          </form>
          <button
            type="button"
            onClick={() => {
              setIdentifier(DEMO_ADMIN.loginId);
              setPassword(DEMO_ADMIN.password);
            }}
            className="mt-3 w-full rounded-xl border border-gold/25 bg-gold/10 px-3 py-2 text-[11px] text-gold hover:bg-gold/20"
          >
            Use demo admin · {DEMO_ADMIN.loginId} / {DEMO_ADMIN.password}
          </button>
          <p className="mt-4 text-center text-[11px] text-cream/35">
            <Link href="/login" className="hover:text-cream">Member sign in →</Link>
          </p>
        </div>
      </div>
    </main>
  );
}
