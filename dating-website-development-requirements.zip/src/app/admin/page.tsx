import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { payments, reports, users } from "@/db/schema";
import { getSessionUser, hasActiveMembership } from "@/lib/auth";
import { ADMIN_UPI_ID, PLAN } from "@/lib/config";
import { ensureSeeded } from "@/lib/seed";
import { AdminAction, AdminLogout } from "@/components/AdminActions";

export const dynamic = "force-dynamic";

function badgeForStatus(status: string) {
  if (status === "active") return "badge-verified";
  if (status === "under_review") return "badge-warn";
  if (status === "banned") return "badge-danger";
  return "badge-muted";
}

export default async function AdminPage() {
  await ensureSeeded();
  const viewer = await getSessionUser();
  if (!viewer) redirect("/admin/login");
  if (viewer.role !== "admin") redirect("/app");

  const members = await db
    .select()
    .from(users)
    .where(eq(users.role, "member"))
    .orderBy(desc(users.createdAt));

  const queue = await db
    .select({ payment: payments, member: users })
    .from(payments)
    .innerJoin(users, eq(users.id, payments.userId))
    .where(inArray(payments.status, ["needs_review", "pending"]))
    .orderBy(desc(payments.createdAt));

  const settled = await db
    .select({ payment: payments, member: users })
    .from(payments)
    .innerJoin(users, eq(users.id, payments.userId))
    .where(inArray(payments.status, ["verified", "rejected"]))
    .orderBy(desc(payments.createdAt))
    .limit(6);

  const openReports = await db
    .select({ report: reports, reporter: users })
    .from(reports)
    .innerJoin(users, eq(users.id, reports.reporterId))
    .where(eq(reports.status, "open"))
    .orderBy(desc(reports.createdAt));

  const memberById = new Map(members.map((m) => [m.id, m]));
  const stats = {
    members: members.length,
    active: members.filter((m) => hasActiveMembership(m)).length,
    pendingPayments: queue.length,
    openReports: openReports.length,
    flagged: members.filter((m) => m.status === "under_review").length,
    banned: members.filter((m) => m.status === "banned").length,
    revenue: settled.filter((s) => s.payment.status === "verified").length * PLAN.amount,
  };

  return (
    <div className="mx-auto max-w-6xl px-5 py-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-rose to-rose-deep">
            ❤
          </span>
          <div>
            <p className="display text-lg leading-tight">Milap admin</p>
            <p className="text-[10px] uppercase tracking-widest text-cream/35">
              Trust &amp; Safety console
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="chip border-gold/30 bg-gold/10 text-[10px] text-gold">
            UPI · {ADMIN_UPI_ID}
          </span>
          <Link href="/" className="text-[11px] text-cream/50 hover:text-cream">View site</Link>
          <AdminLogout />
        </div>
      </header>

      <section className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {[
          ["Members", stats.members, "text-cream"],
          ["Active plans", stats.active, "text-mint"],
          ["Payment queue", stats.pendingPayments, "text-gold"],
          ["Open reports", stats.openReports, "text-rose"],
          ["Quarantined", stats.flagged, "text-gold"],
          ["Collected", `₹${stats.revenue}`, "text-mint"],
        ].map(([label, value, tone]) => (
          <div key={String(label)} className="card p-3.5">
            <p className="text-[9.5px] uppercase tracking-widest text-cream/35">{label}</p>
            <p className={`mt-1 display text-2xl ${tone}`}>{value}</p>
          </div>
        ))}
      </section>

      {/* Payment queue */}
      <section className="mt-6">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="display text-2xl">UTR &amp; payment verification</h2>
            <p className="text-[11px] text-cream/45">
              Auto-verified references activate instantly. These need a human decision.
            </p>
          </div>
          <span className="badge-warn">{queue.length} waiting</span>
        </div>

        <div className="mt-3 space-y-2">
          {queue.map(({ payment, member }) => (
            <div key={payment.id} className="card flex flex-wrap items-center gap-3 p-3">
              <div className="h-20 w-16 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-black/30">
                {payment.screenshotMediaId ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <a href={`/api/media/${payment.screenshotMediaId}`} target="_blank" rel="noreferrer">
                    <img
                      src={`/api/media/${payment.screenshotMediaId}`}
                      alt="Payment proof"
                      className="h-full w-full object-cover"
                    />
                  </a>
                ) : (
                  <div className="grid h-full place-items-center text-[9px] text-cream/30">none</div>
                )}
              </div>
              <div className="min-w-[180px] flex-1">
                <p className="text-[13px] font-semibold">
                  {member.fullName}{" "}
                  <span className="text-[10px] font-normal text-cream/35">@{member.loginId}</span>
                </p>
                <p className="font-mono text-[11.5px] text-cream/70">UTR {payment.utr}</p>
                <p className="text-[10.5px] text-cream/40">
                  ₹{payment.amount} · {new Date(payment.createdAt).toLocaleString()} · trust{" "}
                  {member.trustScore}/100
                </p>
                {payment.checkerNote && (
                  <p className="mt-0.5 max-w-xl text-[10.5px] text-gold/80">{payment.checkerNote}</p>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <AdminAction
                  url={`/api/admin/payment/${payment.id}`}
                  body={{ action: "approve" }}
                  label="Approve & activate"
                  tone="mint"
                />
                <AdminAction
                  url={`/api/admin/payment/${payment.id}`}
                  body={{ action: "reject" }}
                  label="Reject"
                  tone="danger"
                  confirmText="Reject this payment? The member will not get access."
                />
                <AdminAction
                  url={`/api/admin/user/${member.id}`}
                  body={{ action: "flag", note: "Flagged during payment review." }}
                  label="Flag member"
                  tone="ghost"
                />
              </div>
            </div>
          ))}
          {queue.length === 0 && (
            <div className="card p-6 text-center text-[12px] text-cream/40">
              🎉 Payment queue is clear. Auto-verified UTRs activated instantly.
            </div>
          )}
        </div>

        {settled.length > 0 && (
          <div className="card mt-3 p-4">
            <p className="text-[10px] uppercase tracking-widest text-cream/35">Recently settled</p>
            <div className="mt-2 space-y-1.5">
              {settled.map(({ payment, member }) => (
                <div key={payment.id} className="flex flex-wrap items-center gap-2 text-[11px]">
                  <span className="text-cream/70">{member.fullName}</span>
                  <span className="font-mono text-cream/45">UTR {payment.utr}</span>
                  <span className={payment.status === "verified" ? "badge-verified" : "badge-danger"}>
                    {payment.status}
                  </span>
                  <span className="text-cream/30">{new Date(payment.createdAt).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Fake profile / member moderation */}
      <section className="mt-7">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="display text-2xl">Fake-profile detector</h2>
            <p className="text-[11px] text-cream/45">
              Trust score = OTP checks + selfie + photos + bio + location − open reports. Below 50 or
              3 reports triggers quarantine.
            </p>
          </div>
          <div className="flex gap-2">
            <span className="badge-danger">{stats.banned} removed</span>
            <span className="badge-warn">{stats.flagged} quarantined</span>
          </div>
        </div>

        <div className="mt-3 space-y-2">
          {members.map((member) => {
            const memberReports = openReports.filter(
              (r) => r.report.reportedUserId === member.id,
            ).length;
            const risk =
              member.trustScore >= 85 && memberReports === 0
                ? "Low"
                : member.trustScore >= 55
                  ? "Watch"
                  : "High";
            return (
              <div key={member.id} className="card p-3">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="h-16 w-14 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-black/30">
                    {member.photoMediaId || member.photoUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={member.photoMediaId ? `/api/media/${member.photoMediaId}` : member.photoUrl!}
                        alt={member.fullName}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="grid h-full place-items-center text-[9px] text-cream/30">no photo</div>
                    )}
                  </div>
                  <div className="min-w-[200px] flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[13px] font-semibold">{member.fullName}</p>
                      <span className={badgeForStatus(member.status)}>{member.status.replace("_", " ")}</span>
                      <span className={risk === "Low" ? "badge-verified" : risk === "Watch" ? "badge-warn" : "badge-danger"}>
                        {risk} risk
                      </span>
                      {member.identityVerified && <span className="badge-verified">identity ✓</span>}
                    </div>
                    <p className="text-[10.5px] text-cream/45">
                      @{member.loginId} · {member.city} ·{" "}
                      {new Date().getFullYear() - member.birthYear} yrs · joined{" "}
                      {new Date(member.createdAt).toLocaleDateString()}
                    </p>
                    <p className="text-[10.5px] text-cream/40">
                      trust {member.trustScore}/100 · reports {memberReports} ·{" "}
                      {member.emailVerifiedAt ? "email ✓" : "email ✗"} ·{" "}
                      {member.phoneVerifiedAt ? "mobile ✓" : "mobile ✗"} ·{" "}
                      {member.selfieMediaId ? "selfie ✓" : "selfie ✗"} ·{" "}
                      {hasActiveMembership(member)
                        ? `plan active (${member.membershipExpiresAt?.toDateString() ?? "—"})`
                        : `plan ${member.membershipStatus}`}
                    </p>
                    {member.statusReason && (
                      <p className="mt-0.5 text-[10.5px] text-gold/80">{member.statusReason}</p>
                    )}
                  </div>
                  <div className="flex max-w-[280px] flex-wrap gap-1.5">
                    <AdminAction
                      url={`/api/admin/user/${member.id}`}
                      body={{ action: "verify_identity" }}
                      label="Verify"
                      tone="mint"
                    />
                    <AdminAction
                      url={`/api/admin/user/${member.id}`}
                      body={{ action: "grant_membership" }}
                      label="Grant 30d"
                      tone="ghost"
                    />
                    <AdminAction
                      url={`/api/admin/user/${member.id}`}
                      body={{ action: member.status === "under_review" ? "unflag" : "flag" }}
                      label={member.status === "under_review" ? "Clear flag" : "Quarantine"}
                      tone="ghost"
                    />
                    <AdminAction
                      url={`/api/admin/user/${member.id}`}
                      body={{ action: member.status === "banned" ? "restore" : "ban" }}
                      label={member.status === "banned" ? "Restore" : "Ban"}
                      tone="danger"
                      confirmText={
                        member.status === "banned"
                          ? "Restore this account?"
                          : "Ban this account? They will be signed out and hidden."
                      }
                    />
                    <AdminAction
                      url={`/api/admin/user/${member.id}`}
                      method="DELETE"
                      body={{}}
                      label="Delete forever"
                      tone="danger"
                      confirmText="Permanently delete this member, photos, chats and payments?"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Reports */}
      <section className="mt-7">
        <h2 className="display text-2xl">Member reports</h2>
        <p className="text-[11px] text-cream/45">
          {openReports.length} open · three open reports quarantine a profile automatically.
        </p>
        <div className="mt-3 space-y-2">
          {openReports.map(({ report, reporter }) => {
            const reported = memberById.get(report.reportedUserId);
            return (
              <div key={report.id} className="card flex flex-wrap items-center gap-3 p-3">
                <div className="min-w-[220px] flex-1">
                  <p className="text-[13px] font-semibold">
                    {reported?.fullName ?? "Removed member"}{" "}
                    <span className="text-[10px] font-normal text-cream/35">
                      reported by {reporter.fullName}
                    </span>
                  </p>
                  <p className="text-[11px] text-cream/60">{report.reason}</p>
                  {report.details && (
                    <p className="text-[10.5px] text-cream/40">&ldquo;{report.details}&rdquo;</p>
                  )}
                  <p className="text-[10px] text-cream/30">
                    {new Date(report.createdAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex gap-1.5">
                  <AdminAction
                    url={`/api/admin/report/${report.id}`}
                    body={{ action: "dismiss" }}
                    label="Dismiss"
                    tone="ghost"
                  />
                  <AdminAction
                    url={`/api/admin/report/${report.id}`}
                    body={{ action: "uphold" }}
                    label="Uphold & quarantine"
                    tone="primary"
                  />
                  <AdminAction
                    url={`/api/admin/report/${report.id}`}
                    body={{ action: "ban" }}
                    label="Ban reported"
                    tone="danger"
                    confirmText="Ban the reported member?"
                  />
                </div>
              </div>
            );
          })}
          {openReports.length === 0 && (
            <div className="card p-6 text-center text-[12px] text-cream/40">
              No open reports. Member flags and UTR replays still appear above.
            </div>
          )}
        </div>
      </section>

      <p className="mt-8 text-center text-[10px] text-cream/25">
        Payments are collected on {ADMIN_UPI_ID}. Auto-activation only after UTR validation ·
        manual review for suspicious references.
      </p>
    </div>
  );
}
