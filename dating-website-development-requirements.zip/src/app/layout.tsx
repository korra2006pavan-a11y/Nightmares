import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Milap — verified singles near you",
  description:
    "Milap is a verified dating and meet-up platform for single adults. Selfie + email + mobile OTP verification, nearest-first discovery, private contact sharing and a ₹99 monthly membership with UTR-checked UPI payments.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen aurora antialiased">{children}</body>
    </html>
  );
}
