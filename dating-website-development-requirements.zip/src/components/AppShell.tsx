"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import type { Me } from "@/lib/types";

const NAV = [
  { href: "/app", label: "Discover", icon: "🔍" },
  { href: "/app/matches", label: "Matches", icon: "💞" },
  { href: "/app/chat", label: "Chat", icon: "💬" },
  { href: "/app/membership", label: "Membership", icon: "₹" },
  { href: "/app/settings", label: "Settings", icon: "⚙" },
];

export function AppShell({ user, children }: { user: Me; children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [unread, setUnread] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    async function poll() {
      try {
        const res = await fetch("/api/chat", { cache: "no-store" });
        if (!res.ok) return;
        const data = (await res.json()) as { totalUnread?: number };
        if (alive) setUnread(data.totalUnread ?? 0);
      } catch {
        /* ignore polling errors */
      }
    }
    void poll();
    const timer = setInterval(poll, 20000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const active = (href: string) =>
    href === "/app" ? pathname === "/app" : pathname.startsWith(href);

  const verificationMissing = !user.emailVerified || !user.phoneVerified || !user.hasSelfie;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Link href="/app" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-rose to-rose-deep text-sm">
              ❤
            </span>
            <span className="display text-lg">Milap</span>
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`relative rounded-full px-3.5 py-2 text-[13px] transition ${
                  active(item.href)
                    ? "bg-white/10 text-cream"
                    : "text-cream/55 hover:bg-white/5 hover:text-cream"
                }`}
              >
                <span className="mr-1.5 text-[11px] opacity-70">{item.icon}</span>
                {item.label}
                {item.href === "/app/chat" && unread > 0 && (
                  <span className="ml-1.5 rounded-full bg-rose px-1.5 py-0.5 text-[9px] font-bold text-white">
                    {unread}
                  </span>
                )}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link
              href="/app/membership"
              className={
                user.isMember
                  ? "chip border-mint/30 bg-mint/10 text-mint"
                  : "chip border-rose/40 bg-rose/15 text-rose"
              }
            >
              {user.isMember ? `Member · ${user.daysLeft}d left` : "Join · ₹99"}
            </Link>
            <button
              type="button"
              onClick={() => setMenuOpen((prev) => !prev)}
              className="flex items-center gap-2 rounded-full border border-white/12 bg-white/5 py-1 pl-1 pr-3"
            >
              <span className="relative grid h-7 w-7 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-rose/70 to-rose-deep text-[11px] font-bold">
                {user.photoUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={user.photoUrl} alt={user.fullName} className="h-full w-full object-cover" />
                ) : (
                  user.fullName.slice(0, 1).toUpperCase()
                )}
              </span>
              <span className="hidden text-[12px] font-medium sm:block">
                {user.fullName.split(" ")[0]}
              </span>
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="mx-auto max-w-6xl px-4 pb-3">
            <div className="card flex flex-wrap items-center justify-between gap-3 p-3 text-[12px]">
              <div>
                <p className="font-semibold">{user.fullName} · {user.loginId}</p>
                <p className="text-cream/45">
                  Trust score {user.trustScore}/100 ·{" "}
                  {user.identityVerified ? "identity verified" : "identity pending"}
                </p>
              </div>
              <div className="flex gap-2">
                <Link href="/app/settings" className="btn-ghost btn-sm">Settings</Link>
                <button onClick={logout} className="btn-primary btn-sm">Sign out</button>
              </div>
            </div>
          </div>
        )}
      </header>

      {verificationMissing && (
        <div className="border-b border-gold/20 bg-gold/[0.07]">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-2 text-[11px] text-gold">
            <span>
              Finish OTP + selfie verification to keep your profile discoverable.
            </span>
            <Link href="/verify" className="font-semibold underline">Complete verification →</Link>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-5 md:pb-12">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-ink/95 backdrop-blur-xl md:hidden">
        <div className="grid grid-cols-5">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`relative flex flex-col items-center gap-0.5 py-2.5 text-[10px] ${
                active(item.href) ? "text-rose" : "text-cream/45"
              }`}
            >
              <span className="text-base">{item.icon}</span>
              {item.label}
              {item.href === "/app/chat" && unread > 0 && (
                <span className="absolute right-4 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose px-1 text-[9px] font-bold text-white">
                  {unread}
                </span>
              )}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
