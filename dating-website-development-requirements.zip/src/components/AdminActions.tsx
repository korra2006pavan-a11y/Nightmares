"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type Props = {
  url: string;
  method?: "PATCH" | "DELETE";
  body: Record<string, unknown>;
  label: string;
  tone?: "primary" | "ghost" | "danger" | "mint";
  confirmText?: string;
};

const TONES: Record<string, string> = {
  primary: "rounded-full bg-rose px-3 py-1.5 text-[11px] font-semibold text-white hover:brightness-110",
  ghost: "rounded-full border border-white/15 px-3 py-1.5 text-[11px] font-semibold text-cream/70 hover:text-cream",
  danger: "rounded-full border border-rose/40 bg-rose/10 px-3 py-1.5 text-[11px] font-semibold text-rose hover:bg-rose/20",
  mint: "rounded-full border border-mint/40 bg-mint/10 px-3 py-1.5 text-[11px] font-semibold text-mint hover:bg-mint/20",
};

export function AdminAction({ url, method = "PATCH", body, label, tone = "ghost", confirmText }: Props) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function run() {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true);
    setError("");
    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: method === "DELETE" ? undefined : JSON.stringify(body),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) throw new Error(data.error || "Action failed.");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button type="button" onClick={run} disabled={busy} className={TONES[tone]}>
        {busy ? "…" : label}
      </button>
      {error && <span className="text-[10px] text-rose">{error}</span>}
    </span>
  );
}

export function AdminLogout() {
  const router = useRouter();
  return (
    <button
      type="button"
      className="rounded-full border border-white/15 px-3 py-1.5 text-[11px] font-semibold text-cream/70 hover:text-cream"
      onClick={async () => {
        await fetch("/api/auth/logout", { method: "POST" });
        router.push("/");
        router.refresh();
      }}
    >
      Sign out
    </button>
  );
}
