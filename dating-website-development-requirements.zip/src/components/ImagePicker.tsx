"use client";

import { useRef, useState } from "react";
import { fileToDataUrl } from "@/lib/image";

type Props = {
  label: string;
  hint?: string;
  value: string | null;
  onChange: (dataUrl: string | null) => void;
  shape?: "circle" | "square";
  required?: boolean;
};

export function ImagePicker({ label, hint, value, onChange, shape = "square", required }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function handleFile(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const dataUrl = await fileToDataUrl(file, 1000);
      onChange(dataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read the image.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <span className="label">
        {label} {required && <span className="text-rose">*</span>}
      </span>
      <div className="flex items-center gap-4">
        <div
          className={`relative grid shrink-0 place-items-center overflow-hidden border border-dashed border-white/20 bg-black/30 ${
            shape === "circle" ? "h-20 w-20 rounded-full" : "h-24 w-20 rounded-2xl"
          }`}
        >
          {value ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={value} alt={label} className="h-full w-full object-cover" />
          ) : (
            <span className="text-xl text-cream/30">{busy ? "…" : "＋"}</span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="btn-ghost btn-sm"
              disabled={busy}
            >
              {busy ? "Processing…" : value ? "Replace photo" : "Upload photo"}
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange(null)}
                className="btn-sm rounded-full px-3 py-2 text-xs text-cream/50 hover:text-rose"
              >
                Remove
              </button>
            )}
          </div>
          {hint && <p className="mt-2 text-[11px] leading-snug text-cream/40">{hint}</p>}
          {error && <p className="mt-1 text-[11px] text-rose">{error}</p>}
        </div>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(event) => {
          void handleFile(event.target.files?.[0]);
          event.target.value = "";
        }}
      />
    </div>
  );
}
