export const SITE = {
  name: "Milap",
  tagline: "Verified singles. Real meets. No fakes.",
  supportEmail: "care@milap.app",
};

/** Admin collection UPI ID — shown on the join page + inside the UPI QR. */
export const ADMIN_UPI_ID = process.env.ADMIN_UPI_ID || "korra.59@ptaxis";
export const ADMIN_UPI_NAME = process.env.ADMIN_UPI_NAME || "Milap Membership";

/** Monthly join fee in INR. */
export const PLAN = {
  id: "monthly",
  label: "Monthly membership",
  amount: 99,
  days: 30,
};

export const SESSION_COOKIE = "milap_session";
export const SESSION_DAYS = 30;

export const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@milap.in";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Admin@12345";

export const DEMO_MEMBER = { loginId: "ananya", password: "Demo@12345" };
export const DEMO_ADMIN = { loginId: "admin", password: "Admin@12345" };

export const FEATURES = [
  {
    title: "Photo + selfie verification",
    body: "Every profile uploads a live selfie. Our team compares it with the profile photo before the trust badge is issued.",
    icon: "🛡️",
  },
  {
    title: "Email + mobile OTP",
    body: "A 6-digit OTP on both email and mobile keeps throwaway accounts and bots out of the pool.",
    icon: "📲",
  },
  {
    title: "Nearest-first discovery",
    body: "Profiles are ranked by real distance from your coordinates, so a meet-up is never a 3-hour commute.",
    icon: "📍",
  },
  {
    title: "Contact on your terms",
    body: "Your phone number stays hidden by default. Reveal it only to people you choose, or never at all.",
    icon: "🔒",
  },
];
