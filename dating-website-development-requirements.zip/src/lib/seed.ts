import { db } from "@/db";
import {
  likes,
  media,
  messages,
  payments,
  users,
  type User,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_UPI_ID, PLAN } from "@/lib/config";
import { eq } from "drizzle-orm";

const photos = {
  ananya:
    "https://images.pexels.com/photos/31635316/pexels-photo-31635316.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  kavya:
    "https://images.pexels.com/photos/12299161/pexels-photo-12299161.png?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  sneha:
    "https://images.pexels.com/photos/37145167/pexels-photo-37145167.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  priya:
    "https://images.pexels.com/photos/38982379/pexels-photo-38982379.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  arjun:
    "https://images.pexels.com/photos/6102858/pexels-photo-6102858.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  rohit:
    "https://images.pexels.com/photos/7262284/pexels-photo-7262284.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  vikram:
    "https://images.pexels.com/photos/12772053/pexels-photo-12772053.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  kiran:
    "https://images.pexels.com/photos/16928842/pexels-photo-16928842.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
};

const globalForSeed = globalThis as typeof globalThis & {
  __milapSeedPromise?: Promise<void>;
};

export function ensureSeeded(): Promise<void> {
  if (!globalForSeed.__milapSeedPromise) {
    globalForSeed.__milapSeedPromise = seed().catch((error) => {
      console.error("[milap] seed skipped:", error);
      globalForSeed.__milapSeedPromise = undefined;
    });
  }
  return globalForSeed.__milapSeedPromise;
}

async function seed(): Promise<void> {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) return;

  const now = new Date();
  const inDays = (d: number) => new Date(now.getTime() + d * 86_400_000);
  const verified = { emailVerifiedAt: now, phoneVerifiedAt: now, identityVerified: true };

  const [admin] = await db
    .insert(users)
    .values({
      loginId: "admin",
      email: ADMIN_EMAIL,
      phone: "9000000000",
      passwordHash: hashPassword(ADMIN_PASSWORD),
      role: "admin",
      fullName: "Milap Trust & Safety",
      gender: "other",
      birthYear: 1990,
      city: "Hyderabad",
      area: "Trust & Safety desk",
      bio: "Admin account for payment review and fake profile removal.",
      lat: 17.385,
      lng: 78.4867,
      membershipStatus: "active",
      membershipPlan: "staff",
      membershipExpiresAt: inDays(3650),
      trustScore: 100,
      ...verified,
    })
    .returning();

  const rows: Array<Omit<typeof users.$inferInsert, "passwordHash"> & { password?: string }> = [
    {
      loginId: "ananya",
      email: "demo@milap.in",
      phone: "9876500001",
      password: "Demo@12345",
      fullName: "Ananya Rao",
      gender: "female",
      interestedIn: "male",
      birthYear: 1997,
      heightCm: 163,
      city: "Hyderabad",
      area: "Jubilee Hills",
      bio: "Product designer, filter-coffee loyalist and Sunday morning trekker. Looking for someone who texts back and shows up on time.",
      lookingFor: "Long-term",
      lat: 17.4126,
      lng: 78.4076,
      photoUrl: photos.ananya,
      showPhoto: true,
      showContact: false,
      allowChatPhotos: true,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(24),
      trustScore: 100,
      ...verified,
    },
    {
      loginId: "arjun",
      email: "arjun@example.com",
      phone: "9876500002",
      password: "Milap@12345",
      fullName: "Arjun Menon",
      gender: "male",
      interestedIn: "female",
      birthYear: 1995,
      heightCm: 178,
      city: "Hyderabad",
      area: "Gachibowli",
      bio: "Backend engineer by day, bass guitarist by night. I make a dangerously good filter coffee and I am learning to cook biryani.",
      lookingFor: "Long-term",
      lat: 17.4401,
      lng: 78.3489,
      photoUrl: photos.arjun,
      showPhoto: true,
      showContact: true,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(19),
      trustScore: 100,
      ...verified,
    },
    {
      loginId: "rohit",
      email: "rohit@example.com",
      phone: "9876500003",
      password: "Milap@12345",
      fullName: "Rohit Varma",
      gender: "male",
      interestedIn: "female",
      birthYear: 1993,
      heightCm: 174,
      city: "Hyderabad",
      area: "Madhapur",
      bio: "Marketing lead, gym at 6am, balcony gardening at 7pm. Here for something honest — coffee first, labels later.",
      lookingFor: "Dating",
      lat: 17.4483,
      lng: 78.3915,
      photoUrl: photos.rohit,
      showPhoto: true,
      showContact: false,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(11),
      trustScore: 95,
      ...verified,
    },
    {
      loginId: "kavya",
      email: "kavya@example.com",
      phone: "9876500004",
      password: "Milap@12345",
      fullName: "Kavya Iyer",
      gender: "female",
      interestedIn: "male",
      birthYear: 1998,
      city: "Hyderabad",
      area: "Banjara Hills",
      bio: "Chartered accountant who dances salsa on weekends. Big on clear intentions and small on small talk.",
      lookingFor: "Long-term",
      lat: 17.4126,
      lng: 78.4392,
      photoUrl: photos.kavya,
      showPhoto: true,
      showContact: true,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(27),
      trustScore: 100,
      ...verified,
    },
    {
      loginId: "sneha",
      email: "sneha@example.com",
      phone: "9876500005",
      password: "Milap@12345",
      fullName: "Sneha Reddy",
      gender: "female",
      interestedIn: "any",
      birthYear: 1996,
      city: "Secunderabad",
      area: "Marredpally",
      bio: "Veterinary doctor. I will show you photos of every dog I meet. Looking for a plus-one for long drives.",
      lookingFor: "Dating",
      lat: 17.4399,
      lng: 78.4983,
      photoUrl: photos.sneha,
      showPhoto: true,
      showContact: false,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(8),
      trustScore: 100,
      ...verified,
    },
    {
      loginId: "vikram",
      email: "vikram@example.com",
      phone: "9876500006",
      password: "Milap@12345",
      fullName: "Vikram Naidu",
      gender: "male",
      interestedIn: "female",
      birthYear: 1992,
      city: "Hyderabad",
      area: "Kukatpally",
      bio: "Civil contractor. Early riser, bikes on weekends, terrible at texting but great at showing up.",
      lookingFor: "Long-term",
      lat: 17.4948,
      lng: 78.3996,
      photoUrl: photos.vikram,
      showPhoto: true,
      showContact: true,
      membershipStatus: "pending",
      membershipPlan: null,
      membershipExpiresAt: null,
      trustScore: 72,
      emailVerifiedAt: now,
      phoneVerifiedAt: now,
      identityVerified: false,
    },
    {
      loginId: "priya",
      email: "priya@example.com",
      phone: "9876500007",
      password: "Milap@12345",
      fullName: "Priya Sharma",
      gender: "female",
      interestedIn: "male",
      birthYear: 1999,
      city: "Visakhapatnam",
      area: "MVP Colony",
      bio: "Final-year marine biology student. Beach person, filter coffee hater, will beat you at badminton.",
      lookingFor: "Dating",
      lat: 17.6868,
      lng: 83.2185,
      photoUrl: photos.priya,
      showPhoto: true,
      showContact: false,
      membershipStatus: "none",
      trustScore: 63,
      emailVerifiedAt: now,
      phoneVerifiedAt: now,
      identityVerified: false,
    },
    {
      loginId: "kiran",
      email: "kiran@example.com",
      phone: "9876500008",
      password: "Milap@12345",
      fullName: "Kiran Kumar",
      gender: "male",
      interestedIn: "female",
      birthYear: 1994,
      city: "Vijayawada",
      area: "Benz Circle",
      bio: "Chef running a small cloud kitchen. I will feed you first and flirt second. Family is important to me.",
      lookingFor: "Long-term",
      lat: 16.5062,
      lng: 80.648,
      photoUrl: photos.kiran,
      showPhoto: true,
      showContact: true,
      membershipStatus: "active",
      membershipPlan: PLAN.id,
      membershipExpiresAt: inDays(21),
      trustScore: 100,
      ...verified,
    },
    {
      loginId: "imran",
      email: "imran@example.com",
      phone: "9876500009",
      password: "Milap@12345",
      fullName: "Imran Khan",
      gender: "male",
      interestedIn: "female",
      birthYear: 1990,
      city: "Hyderabad",
      area: "Charminar",
      bio: "Hey.",
      lookingFor: "Hookup",
      lat: 17.3616,
      lng: 78.4747,
      photoUrl: null,
      showPhoto: false,
      showContact: false,
      membershipStatus: "pending",
      status: "under_review",
      statusReason:
        "Fake-profile detector: unverified selfie, no profile photo and 3 member reports.",
      trustScore: 12,
      emailVerifiedAt: now,
      phoneVerifiedAt: null,
      identityVerified: false,
    },
  ];

  const inserted: User[] = [];
  for (const row of rows) {
    const { password, ...rest } = row;
    const [user] = await db
      .insert(users)
      .values({ ...rest, passwordHash: hashPassword(password ?? "Milap@12345") })
      .returning();
    inserted.push(user);
  }

  const byLogin = (login: string) => inserted.find((u) => u.loginId === login)!;
  const ananya = byLogin("ananya");
  const arjun = byLogin("arjun");
  const rohit = byLogin("rohit");
  const kavya = byLogin("kavya");
  const vikram = byLogin("vikram");
  const imran = byLogin("imran");

  await db.insert(likes).values([
    { fromUserId: arjun.id, toUserId: ananya.id, action: "like" },
    { fromUserId: ananya.id, toUserId: arjun.id, action: "like" },
    { fromUserId: rohit.id, toUserId: ananya.id, action: "like" },
    { fromUserId: ananya.id, toUserId: rohit.id, action: "like" },
    { fromUserId: kavya.id, toUserId: arjun.id, action: "like" },
    { fromUserId: vikram.id, toUserId: ananya.id, action: "like" },
    { fromUserId: ananya.id, toUserId: kavya.id, action: "like" },
  ]);

  await db.insert(messages).values([
    {
      senderId: arjun.id,
      receiverId: ananya.id,
      body: "Hey Ananya! Your trek photos look great — which trail was that?",
      createdAt: new Date(now.getTime() - 3_600_000 * 5),
      readAt: new Date(now.getTime() - 3_500_000 * 5),
    },
    {
      senderId: ananya.id,
      receiverId: arjun.id,
      body: "Ananthagiri hills, sunrise batch! Do you trek or is the guitar more your thing?",
      createdAt: new Date(now.getTime() - 3_600_000 * 4),
      readAt: new Date(now.getTime() - 3_500_000 * 4),
    },
    {
      senderId: arjun.id,
      receiverId: ananya.id,
      body: "Both, honestly. There is a filter coffee place in Gachibowli I have been gatekeeping. Coffee this Saturday?",
      createdAt: new Date(now.getTime() - 3_600_000 * 2),
    },
    {
      senderId: rohit.id,
      receiverId: ananya.id,
      body: "Hi Ananya, we matched! Sunday farmers market in Madhapur, if you are free?",
      createdAt: new Date(now.getTime() - 3_600_000 * 26),
    },
  ]);

  // A small pending payment so the admin review queue is not empty on day one.
  const [proof] = await db
    .insert(media)
    .values({
      ownerId: vikram.id,
      kind: "payment",
      mime: "image/svg+xml",
      byteSize: 512,
      data: Buffer.from(
        `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="720"><rect width="420" height="720" fill="#0f172a"/><text x="32" y="80" fill="#fff" font-family="sans-serif" font-size="24">UPI Payment Successful</text><text x="32" y="140" fill="#94a3b8" font-family="sans-serif" font-size="18">₹99.00 to ${ADMIN_UPI_ID}</text><text x="32" y="200" fill="#94a3b8" font-family="sans-serif" font-size="18">UTR: 402219876531</text><text x="32" y="260" fill="#22d3ee" font-family="sans-serif" font-size="16">demo screenshot</text></svg>`,
      ).toString("base64"),
    })
    .returning();

  await db.insert(payments).values({
    userId: vikram.id,
    amount: PLAN.amount,
    upiId: ADMIN_UPI_ID,
    utr: "402219876531",
    screenshotMediaId: proof.id,
    status: "needs_review",
    verdict: "needs_review",
    checkerNote: "First submission from this account. Awaiting admin cross-check with bank credit.",
  });

  console.log("[milap] seeded", inserted.length + 1, "accounts; admin id", admin.id);
}

export async function getDemoUser(): Promise<User | null> {
  const rows = await db.select().from(users).where(eq(users.loginId, "ananya")).limit(1);
  return rows[0] ?? null;
}
