export type Me = {
  id: number;
  loginId: string;
  email: string;
  phone: string;
  role: string;
  fullName: string;
  gender: string;
  interestedIn: string;
  age: number;
  city: string;
  area: string;
  bio: string;
  lookingFor: string;
  photoUrl: string | null;
  hasSelfie: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  identityVerified: boolean;
  membershipStatus: string;
  membershipExpiresAt: string | null;
  daysLeft: number;
  isMember: boolean;
  trustScore: number;
  status: string;
  showPhoto: boolean;
  showContact: boolean;
  allowChatPhotos: boolean;
  hasLocation: boolean;
  lat: number | null;
  lng: number | null;
};

export type Person = {
  id: number;
  loginId: string;
  fullName: string;
  firstName: string;
  age: number;
  gender: string;
  city: string;
  area: string;
  bio: string;
  lookingFor: string;
  photoUrl: string | null;
  photoLocked: boolean;
  photoHiddenByUser: boolean;
  distanceKm: number | null;
  identityVerified: boolean;
  isPremium: boolean;
  contactPhone: string | null;
  contactLocked: boolean;
  showContact: boolean;
  lastActive: string | null;
  trustScore: number;
  memberSince: string;
  status: string;
};

export type NearbyPerson = Person & {
  isMatch: boolean;
  likedYou: boolean;
  youLiked: boolean;
};

export type NearbyData = {
  signedIn: boolean;
  isMember: boolean;
  viewerName: string | null;
  origin: { lat: number; lng: number; label: string; fallback: boolean } | null;
  radiusKm: number;
  count: number;
  people: NearbyPerson[];
};

export type ProfileDetail = {
  profile: Person;
  viewer: { signedIn: boolean; isMember: boolean; isSelf: boolean };
  interaction: { youLiked: boolean; likedYou: boolean; match: boolean; canChat: boolean };
  safety: { openReports: number };
  online: boolean;
};

export type MatchData = {
  isMember: boolean;
  matches: Person[];
  likesYou: Person[];
  pending: Person[];
  counts: { matches: number; likesYou: number; pending: number };
};

export type ChatSummary = {
  userId: number;
  fullName: string;
  photoUrl: string | null;
  city: string;
  area: string;
  identityVerified: boolean;
  unread: number;
  lastMessage: { body: string; hasImage: boolean; fromMe: boolean; at: string } | null;
};

export type ChatListData = {
  isMember: boolean;
  totalUnread: number;
  threads: ChatSummary[];
};

export type ChatMessage = {
  id: number;
  body: string;
  mediaId: number | null;
  fromMe: boolean;
  at: string;
  read: boolean;
  imageUrl: string | null;
  imageBlocked: boolean;
};

export type ThreadData = {
  partner: {
    id: number;
    fullName: string;
    loginId: string;
    city: string;
    area: string;
    photoUrl: string | null;
    identityVerified: boolean;
    showContact: boolean;
    phone: string | null;
    allowChatPhotos: boolean;
  };
  isMember: boolean;
  isMatch: boolean;
  viewerAllowChatPhotos: boolean;
  messages: ChatMessage[];
};

export type PaymentRecord = {
  id: number;
  utr: string;
  amount: number;
  status: string;
  verdict: string;
  checkerNote: string | null;
  screenshotUrl: string | null;
  createdAt: string;
};

export type PaymentData = {
  plan: {
    id: string;
    label: string;
    amount: number;
    days: number;
    upiId: string;
    upiName: string;
    note: string;
  };
  upiLink: string;
  requirements: {
    emailVerified: boolean;
    phoneVerified: boolean;
    hasPhoto: boolean;
    hasSelfie: boolean;
    isMember: boolean;
  };
  membership: { status: string; expiresAt: string | null; daysLeft: number };
  payments: PaymentRecord[];
};
