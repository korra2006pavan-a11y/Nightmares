import { and, eq, inArray, ne } from "drizzle-orm";
import { db } from "@/db";
import { media, reports, users, type User } from "@/db/schema";
import { ADMIN_UPI_ID, PLAN } from "@/lib/config";
import { hasActiveMembership, isFullyVerified } from "@/lib/auth";

export type Verdict = "verified" | "needs_review" | "rejected";

export type UtrCheck = {
  verdict: Verdict;
  ok: boolean;
  code: string;
  message: string;
};

/**
 * UTR (UPI transaction reference) checker.
 *
 * Rules
 *  1. Must be a 12-digit numeric UPI reference.
 *  2. Must never have been used before (replay / screenshot reuse detection).
 *  3. Must be attached to a payment screenshot.
 *  4. All-same-digit refs, or 4+ submissions in 24h, are parked for manual review.
 *
 * A `verified` verdict activates membership immediately.
 */
export async function runUtrCheck(input: {
  utr: string;
  userId: number;
  screenshotMediaId: number | null;
  recentSubmissions: number;
  amount: number;
}): Promise<UtrCheck> {
  const utr = input.utr.replace(/\s+/g, "");

  if (!/^\d{12}$/.test(utr)) {
    return {
      verdict: "rejected",
      ok: false,
      code: "BAD_FORMAT",
      message: "UTR must be the 12-digit numeric reference from your UPI app.",
    };
  }
  if (/^(\d)\1{11}$/.test(utr)) {
    return {
      verdict: "needs_review",
      ok: false,
      code: "FAKE_PATTERN",
      message: "This UTR looks fabricated (repeating digits). A human will review it.",
    };
  }
  if (input.amount !== PLAN.amount) {
    return {
      verdict: "needs_review",
      ok: false,
      code: "AMOUNT_MISMATCH",
      message: `Payment amount must be ₹${PLAN.amount}.`,
    };
  }
  if (!input.screenshotMediaId) {
    return {
      verdict: "rejected",
      ok: false,
      code: "NO_SCREENSHOT",
      message: "Payment screenshot is required before the UTR can be checked.",
    };
  }

  // Replay protection: has this reference already been used by anyone?
  const { payments } = await import("@/db/schema");
  const existing = await db
    .select({ id: payments.id, userId: payments.userId, status: payments.status })
    .from(payments)
    .where(eq(payments.utr, utr))
    .limit(1);

  if (existing.length > 0) {
    const same = existing[0].userId === input.userId;
    return {
      verdict: "rejected",
      ok: false,
      code: same ? "DUPLICATE_OWN" : "DUPLICATE_OTHER",
      message: same
        ? "You already submitted this UTR. If it was approved, membership is active."
        : "This UTR is already attached to another account. Possible screenshot reuse — blocked.",
    };
  }

  if (input.recentSubmissions >= 4) {
    return {
      verdict: "needs_review",
      ok: false,
      code: "VELOCITY",
      message: "Too many payment attempts in 24 hours. Parked for manual verification.",
    };
  }

  return {
    verdict: "verified",
    ok: true,
    code: "PASS",
    message: `UTR format valid, screenshot attached, reference unused. Verified against ${ADMIN_UPI_ID}.`,
  };
}

/* ------------------------------------------------------------------ */
/* Trust score — used to surface & remove fake profiles                */
/* ------------------------------------------------------------------ */

export function computeTrustScore(
  user: Pick<
    User,
    | "photoUrl"
    | "photoMediaId"
    | "selfieMediaId"
    | "emailVerifiedAt"
    | "phoneVerifiedAt"
    | "identityVerified"
    | "bio"
    | "lat"
    | "lng"
    | "city"
  >,
  openReports: number,
): number {
  let score = 0;
  if (user.emailVerifiedAt) score += 25;
  if (user.phoneVerifiedAt) score += 25;
  if (user.selfieMediaId || user.identityVerified) score += 15;
  if (user.photoUrl || user.photoMediaId) score += 15;
  if ((user.bio ?? "").trim().length >= 20) score += 8;
  if (user.lat !== null && user.lng !== null && user.city) score += 12;
  score -= openReports * 20;
  return Math.max(0, Math.min(100, score));
}

export async function refreshTrust(userId: number): Promise<number> {
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return 0;
  const open = await db
    .select({ id: reports.id })
    .from(reports)
    .where(and(eq(reports.reportedUserId, userId), eq(reports.status, "open")));
  const score = computeTrustScore(user, open.length);
  const patch: Partial<typeof users.$inferInsert> = { trustScore: score };

  // Automatic quarantine for heavily reported profiles (fake-account defence).
  if (open.length >= 3 && user.status === "active" && user.role !== "admin") {
    patch.status = "under_review";
    patch.statusReason = `${open.length} open reports from members — quarantined by the fake-profile detector.`;
  }
  await db.update(users).set(patch).where(eq(users.id, userId));
  return score;
}

export function fakeRiskLabel(score: number, openReports: number): string {
  if (openReports >= 3) return "High risk";
  if (score >= 85) return "Low risk";
  if (score >= 55) return "Watch";
  return "High risk";
}

/* ------------------------------------------------------------------ */
/* Public serialisation                                                */
/* ------------------------------------------------------------------ */

export type PublicProfile = {
  id: number;
  loginId: string;
  fullName: string;
  firstName: string;
  age: number;
  gender: string;
  city: string;
  area: string;
  bio: string;
  lookingFor: string;
  photoUrl: string | null;
  photoLocked: boolean;
  photoHiddenByUser: boolean;
  distanceKm: number | null;
  identityVerified: boolean;
  isPremium: boolean;
  contactPhone: string | null;
  contactLocked: boolean;
  showContact: boolean;
  lastActive: string | null;
  trustScore: number;
  memberSince: string;
  status: string;
};

export function toPublicProfile(
  target: User,
  opts: {
    viewer: User | null;
    distanceKm: number | null;
    contactUnlocked: boolean;
  },
): PublicProfile {
  const viewerIsMember = opts.viewer ? hasActiveMembership(opts.viewer) : false;
  const isSelf = opts.viewer?.id === target.id;
  const photoAllowed = (viewerIsMember && target.showPhoto) || isSelf;
  const contactAllowed = (viewerIsMember && target.showContact && opts.contactUnlocked) || isSelf;
  return {
    id: target.id,
    loginId: target.loginId,
    fullName: target.showPhoto && !photoAllowed ? shortName(target.fullName) : target.fullName,
    firstName: target.fullName.split(" ")[0] ?? target.loginId,
    age: new Date().getFullYear() - target.birthYear,
    gender: target.gender,
    city: target.city,
    area: viewerIsMember || isSelf ? target.area : "",
    bio: target.bio,
    lookingFor: target.lookingFor,
    photoUrl: photoAllowed ? target.photoUrl : null,
    photoLocked: !photoAllowed,
    photoHiddenByUser: !target.showPhoto,
    distanceKm: opts.distanceKm,
    identityVerified: target.identityVerified && isFullyVerified(target),
    isPremium: hasActiveMembership(target),
    contactPhone: contactAllowed ? target.phone : null,
    contactLocked: Boolean(target.showContact && !contactAllowed && !isSelf),
    showContact: target.showContact,
    lastActive: target.lastActiveAt ? new Date(target.lastActiveAt).toISOString() : null,
    trustScore: target.trustScore,
    memberSince: new Date(target.createdAt).toISOString(),
    status: target.status,
  };
}

function shortName(name: string): string {
  const parts = name.trim().split(/\s+/);
  return `${parts[0] ?? ""} ${(parts[1]?.[0] ?? "")}.`.trim();
}

export async function mutualMatchIds(userId: number): Promise<number[]> {
  const { likes } = await import("@/db/schema");
  const mine = await db
    .select({ to: likes.toUserId })
    .from(likes)
    .where(and(eq(likes.fromUserId, userId), eq(likes.action, "like")));
  const targets = mine.map((row) => row.to);
  if (targets.length === 0) return [];
  const back = await db
    .select({ from: likes.fromUserId })
    .from(likes)
    .where(
      and(
        eq(likes.toUserId, userId),
        eq(likes.action, "like"),
        inArray(likes.fromUserId, targets),
      ),
    );
  return back.map((row) => row.from);
}

export async function mediaBelongsTo(mediaId: number, ownerId: number): Promise<boolean> {
  const rows = await db
    .select({ ownerId: media.ownerId })
    .from(media)
    .where(eq(media.id, mediaId))
    .limit(1);
  return rows[0]?.ownerId === ownerId;
}

export async function otherMemberExists(viewerId: number, targetId: number) {
  if (viewerId === targetId) return null;
  const rows = await db
    .select()
    .from(users)
    .where(and(eq(users.id, targetId), ne(users.status, "banned"), eq(users.role, "member")))
    .limit(1);
  return rows[0] ?? null;
}
