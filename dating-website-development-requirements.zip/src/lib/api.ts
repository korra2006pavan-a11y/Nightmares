import { NextResponse } from "next/server";
import { db } from "@/db";
import { media, type User } from "@/db/schema";
import { getSessionUser, hasActiveMembership, membershipDaysLeft } from "@/lib/auth";
import { ageFromBirthYear } from "@/lib/geo";

export function ok<T>(data: T, init?: number) {
  return NextResponse.json(data as object, { status: init ?? 200 });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status });
}

export async function requireUser(): Promise<
  { user: User; error: null } | { user: null; error: NextResponse }
> {
  const user = await getSessionUser();
  if (!user) return { user: null, error: fail("Please sign in to continue.", 401) };
  if (user.status === "banned") {
    return { user: null, error: fail("This account has been removed for policy violations.", 403) };
  }
  return { user, error: null };
}

export async function requireAdmin(): Promise<
  { user: User; error: null } | { user: null; error: NextResponse }
> {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") {
    return { user: null, error: fail("Admin access only.", 403) };
  }
  return { user, error: null };
}

export async function requireMember(): Promise<
  { user: User; error: null } | { user: null; error: NextResponse }
> {
  const session = await requireUser();
  if (!session.user) return session;
  if (!hasActiveMembership(session.user)) {
    return {
      user: null,
      error: fail("Active ₹99 membership required. Verify your UTR payment to unlock.", 402),
    };
  }
  return session;
}

export async function readJson<T>(request: Request): Promise<T | null> {
  try {
    return (await request.json()) as T;
  } catch {
    return null;
  }
}

const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml"];
const MAX_BYTES = 3.5 * 1024 * 1024;

export type ParsedImage = { mime: string; base64: string; byteSize: number };

export function parseDataUrl(value: unknown): ParsedImage | null {
  if (typeof value !== "string") return null;
  const match = /^data:([a-z0-9/+.-]+);base64,(.+)$/i.exec(value.trim());
  if (!match) return null;
  const mime = match[1].toLowerCase();
  if (!ALLOWED_MIME.includes(mime)) return null;
  const base64 = match[2].replace(/\s/g, "");
  const byteSize = Math.floor((base64.length * 3) / 4);
  if (byteSize > MAX_BYTES) return null;
  return { mime, base64, byteSize };
}

export async function saveMedia(
  ownerId: number,
  kind: "photo" | "selfie" | "payment" | "chat",
  image: ParsedImage,
): Promise<number> {
  const [row] = await db
    .insert(media)
    .values({
      ownerId,
      kind,
      mime: image.mime,
      data: image.base64,
      byteSize: image.byteSize,
    })
    .returning({ id: media.id });
  return row.id;
}

export function photoSrc(user: Pick<User, "photoMediaId" | "photoUrl">): string | null {
  if (user.photoMediaId) return `/api/media/${user.photoMediaId}`;
  return user.photoUrl ?? null;
}

export type Me = {
  id: number;
  loginId: string;
  email: string;
  phone: string;
  role: string;
  fullName: string;
  gender: string;
  interestedIn: string;
  age: number;
  city: string;
  area: string;
  bio: string;
  lookingFor: string;
  photoUrl: string | null;
  hasSelfie: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  identityVerified: boolean;
  membershipStatus: string;
  membershipExpiresAt: string | null;
  daysLeft: number;
  isMember: boolean;
  trustScore: number;
  status: string;
  showPhoto: boolean;
  showContact: boolean;
  allowChatPhotos: boolean;
  hasLocation: boolean;
  lat: number | null;
  lng: number | null;
};

export function serializeMe(user: User): Me {
  return {
    id: user.id,
    loginId: user.loginId,
    email: user.email,
    phone: user.phone,
    role: user.role,
    fullName: user.fullName,
    gender: user.gender,
    interestedIn: user.interestedIn,
    age: ageFromBirthYear(user.birthYear),
    city: user.city,
    area: user.area,
    bio: user.bio,
    lookingFor: user.lookingFor,
    photoUrl: photoSrc(user),
    hasSelfie: Boolean(user.selfieMediaId),
    emailVerified: Boolean(user.emailVerifiedAt),
    phoneVerified: Boolean(user.phoneVerifiedAt),
    identityVerified: user.identityVerified,
    membershipStatus: user.membershipStatus,
    membershipExpiresAt: user.membershipExpiresAt
      ? new Date(user.membershipExpiresAt).toISOString()
      : null,
    daysLeft: membershipDaysLeft(user),
    isMember: hasActiveMembership(user),
    trustScore: user.trustScore,
    status: user.status,
    showPhoto: user.showPhoto,
    showContact: user.showContact,
    allowChatPhotos: user.allowChatPhotos,
    hasLocation: user.lat !== null && user.lng !== null,
    lat: user.lat,
    lng: user.lng,
  };
}
