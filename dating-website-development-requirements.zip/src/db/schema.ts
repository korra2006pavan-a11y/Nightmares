import {
  boolean,
  doublePrecision,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * Milap — verified singles near you.
 * Roles: "member" | "admin"
 * Membership: "none" | "pending" | "active" | "expired"
 * Account status: "active" | "under_review" | "banned"
 */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    loginId: varchar("login_id", { length: 40 }).notNull(),
    email: varchar("email", { length: 160 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 16 }).notNull().default("member"),
    fullName: varchar("full_name", { length: 80 }).notNull(),
    gender: varchar("gender", { length: 12 }).notNull().default("other"),
    interestedIn: varchar("interested_in", { length: 12 }).notNull().default("any"),
    birthYear: integer("birth_year").notNull().default(1996),
    heightCm: integer("height_cm"),
    city: varchar("city", { length: 80 }).notNull().default(""),
    area: varchar("area", { length: 120 }).notNull().default(""),
    bio: text("bio").notNull().default(""),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    lookingFor: varchar("looking_for", { length: 40 }).notNull().default("Long-term"),
    photoUrl: text("photo_url"),
    photoMediaId: integer("photo_media_id"),
    selfieMediaId: integer("selfie_media_id"),
    showPhoto: boolean("show_photo").notNull().default(true),
    showContact: boolean("show_contact").notNull().default(false),
    allowChatPhotos: boolean("allow_chat_photos").notNull().default(true),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    phoneVerifiedAt: timestamp("phone_verified_at", { withTimezone: true }),
    identityVerified: boolean("identity_verified").notNull().default(false),
    membershipStatus: varchar("membership_status", { length: 16 })
      .notNull()
      .default("none"),
    membershipPlan: varchar("membership_plan", { length: 24 }),
    membershipExpiresAt: timestamp("membership_expires_at", { withTimezone: true }),
    status: varchar("status", { length: 16 }).notNull().default("active"),
    statusReason: text("status_reason"),
    trustScore: integer("trust_score").notNull().default(0),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("users_login_id_unique").on(table.loginId),
    uniqueIndex("users_email_unique").on(table.email),
    uniqueIndex("users_phone_unique").on(table.phone),
    index("users_city_idx").on(table.city),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 80 }).primaryKey(),
    userId: integer("user_id").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").notNull(),
  kind: varchar("kind", { length: 24 }).notNull().default("photo"),
  mime: varchar("mime", { length: 60 }).notNull().default("image/jpeg"),
  data: text("data").notNull(),
  byteSize: integer("byte_size").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const otps = pgTable(
  "otps",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    channel: varchar("channel", { length: 12 }).notNull(),
    code: varchar("code", { length: 6 }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("otps_user_channel_idx").on(table.userId, table.channel)],
);

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    plan: varchar("plan", { length: 24 }).notNull().default("monthly"),
    amount: integer("amount").notNull().default(99),
    upiId: varchar("upi_id", { length: 80 }).notNull(),
    utr: varchar("utr", { length: 24 }).notNull(),
    screenshotMediaId: integer("screenshot_media_id"),
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    verdict: varchar("verdict", { length: 24 }).notNull().default("pending"),
    checkerNote: text("checker_note"),
    reviewedBy: integer("reviewed_by"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("payments_utr_unique").on(table.utr),
    index("payments_user_idx").on(table.userId),
  ],
);

export const likes = pgTable(
  "likes",
  {
    id: serial("id").primaryKey(),
    fromUserId: integer("from_user_id").notNull(),
    toUserId: integer("to_user_id").notNull(),
    action: varchar("action", { length: 12 }).notNull().default("like"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("likes_pair_unique").on(table.fromUserId, table.toUserId),
    index("likes_to_idx").on(table.toUserId),
  ],
);

export const reports = pgTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    reporterId: integer("reporter_id").notNull(),
    reportedUserId: integer("reported_user_id").notNull(),
    reason: varchar("reason", { length: 60 }).notNull(),
    details: text("details").notNull().default(""),
    status: varchar("status", { length: 16 }).notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (table) => [index("reports_reported_idx").on(table.reportedUserId)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    senderId: integer("sender_id").notNull(),
    receiverId: integer("receiver_id").notNull(),
    body: text("body").notNull().default(""),
    mediaId: integer("media_id"),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("messages_sender_idx").on(table.senderId),
    index("messages_receiver_idx").on(table.receiverId),
  ],
);

export type User = typeof users.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Report = typeof reports.$inferSelect;
